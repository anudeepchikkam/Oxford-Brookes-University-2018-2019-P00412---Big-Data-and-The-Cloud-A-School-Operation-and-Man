import express from 'express';
const router = express.Router();

// Require Module model in our routes module
import Module from '../models/Module';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    Module.find((err, modules) => {
        if (err) {
            res.json(err);
        } else {
            res.json(modules);
        }
    });
});

// Retrieves a module based on the ID
router.route('/:id').get((req, res) => {
    const id = req.params.id
    Module.findById(id, (err, module) => {
        if (err) {
            console.log(`Error fetching module based on id ${id}: ${err}`)
            return res.json(err)
        } else {
            return res.status(200).json(module)
        }
    })
})

// Defined store route
router.route('/').post((req, res) => {
    const module = new Module(req.body);

    module
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Module successfully created',
            });
        })
        .catch(() => {
            res.status(400).send('Unable to create Module');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    Module.findById(id, (err, module) => {
        if (err) {
            res.json(err);
        }
        res.json(module);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    Module.findById(req.params.id, (err, module) => {
        if (!module) res.status(404).send('data is not found');
        else {
            module.name = req.body.name;
            module.teacherName = req.body.teacherName;
            module.yearGroup = req.body.yearGroup;
            module.syllabus = req.body.syllabus;
            module.markingCriteria = req.body.markingCriteria;
            module
                .save()
                .then(() => {
                    res.json('Module updated successfully');
                })
                .catch((error) => {
                    console.log(error)
                    res.status(400).send('Unable to update Module');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    Module.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, module) => {
            if (err) res.json(err);
            else res.json('Module successfully removed');
        },
    );
});

export default router;
