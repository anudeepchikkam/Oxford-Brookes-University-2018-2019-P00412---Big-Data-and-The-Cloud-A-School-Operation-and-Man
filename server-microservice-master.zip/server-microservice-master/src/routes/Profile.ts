import express from 'express';
const router = express.Router();

// Require Profile model in our routes module
import Profile from '../models/Profile';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    Profile.find((err, profiles) => {
        if (err) {
            res.json(err);
        } else {
            res.json(profiles);
        }
    });
});

// Defined store route
router.route('/').post((req, res) => {
    const profile = new Profile(req.body);

    profile
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Profile successfully created',
            });
        })
        .catch(err => {
            res.status(400).send('Unable to create Profile ' + err);
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    Profile.findById(id, (err, profile) => {
        if (err) {
            res.json(err);
        }
        res.json(profile);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    Profile.findById(req.params.id, (err, profile) => {
        if (!profile) res.status(404).send('data is not found');
        else {
            profile.user_id = req.body.user_id;
            profile.first_name = req.body.first_name;
            profile.last_name = req.body.last_name;
            profile.phone = req.body.phone;
            profile.mobile = req.body.mobile;
            profile.email = req.body.email;
            profile
                .save()
                .then(() => {
                    res.json('Profile updated successfully');
                })
                .catch(err => {
                    res.status(400).send('Unable to update Profile ' + err);
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    Profile.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, profile) => {
            if (err) res.json(err);
            else res.json('Profile successfully removed');
        },
    );
});

export default router;
