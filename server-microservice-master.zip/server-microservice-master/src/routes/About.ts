import express from 'express';
const router = express.Router();

// Require About model in our routes module
import About from '../models/About';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    About.find((err, abouts) => {
        if (err) {
            res.json(err);
        } else {
            res.json(abouts);
        }
    });
});

// Defined get latest data(index or listing) route

router.route('/latest').get((req, res) => {
    About.findOne()
        .sort({ _id: -1 })
        .limit(1)
        .exec((err, about) => {
            if (err) {
                res.json(err);
            } else {
                res.json(about);
            }
        });
});

// Defined store route
router.route('/').post((req, res) => {
    const about = new About(req.body);

    about
        .save()
        .then(() => {
            res.status(200).json({
                message: 'About successfully created',
            });
        })
        .catch(() => {
            res.status(400).send('Unable to create About');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    About.findById(id, (err, about) => {
        if (err) {
            res.json(err);
        }
        res.json(about);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    About.findById(req.params.id, (err, about) => {
        if (!about) res.status(404).send('data is not found');
        else {
            about.content = req.body.content;
            about
                .save()
                .then(() => {
                    res.json('About updated successfully');
                })
                .catch(() => {
                    res.status(400).send('Unable to update About');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    About.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, about) => {
            if (err) res.json(err);
            else res.json('About successfully removed');
        },
    );
});

export default router;
