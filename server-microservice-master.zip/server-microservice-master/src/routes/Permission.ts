import express from 'express';
const router = express.Router();

// Require Permission model in our routes module
import Permission from '../models/Permission';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    Permission.find((err, permissions) => {
        if (err) {
            res.json(err);
        } else {
            res.json(permissions);
        }
    });
});

// Defined store route
router.route('/').post((req, res) => {
    const permission = new Permission(req.body);

    permission
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Permission successfully created',
            });
        })
        .catch(err => {
            res.status(400).send('Unable to create Permission ' + err);
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    Permission.findById(id, (err, permission) => {
        if (err) {
            res.json(err);
        }
        res.json(permission);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    Permission.findById(req.params.id, (err, permission) => {
        if (!permission) res.status(404).send('data is not found');
        else {
            permission.slug = req.body.slug;
            permission.name = req.body.name;
            permission
                .save()
                .then(() => {
                    res.json('Permission updated successfully');
                })
                .catch(err => {
                    console.log(err);
                    res.status(400).send('Unable to update Permission ' + err);
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    Permission.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, permission) => {
            if (err) res.json(err);
            else res.json('Permission successfully removed');
        },
    );
});

export default router;
