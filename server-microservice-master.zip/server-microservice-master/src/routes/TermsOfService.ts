import express from 'express';
const router = express.Router();

// Require TermsOfService model in our routes module
import TermsOfService from '../models/TermsOfService';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    TermsOfService.find((err, termsofservices) => {
        if (err) {
            res.json(err);
        } else {
            res.json(termsofservices);
        }
    });
});

// Defined get latest data(index or listing) route

router.route('/latest').get((req, res) => {
    TermsOfService.findOne()
        .sort({ _id: -1 })
        .limit(1)
        .exec((err, termsofservice) => {
            if (err) {
                res.json(err);
            } else {
                res.json(termsofservice);
            }
        });
});

// Defined store route
router.route('/').post((req, res) => {
    const termsofservice = new TermsOfService(req.body);

    termsofservice
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Terms of service successfully created',
            });
        })
        .catch(() => {
            res.status(400).send('Unable to create Terms of service');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    TermsOfService.findById(id, (err, termsofservice) => {
        if (err) {
            res.json(err);
        }
        res.json(termsofservice);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    TermsOfService.findById(req.params.id, (err, termsofservice) => {
        if (!termsofservice) res.status(404).send('data is not found');
        else {
            termsofservice.content = req.body.content;
            termsofservice
                .save()
                .then(() => {
                    res.json('Terms of service updated successfully');
                })
                .catch(() => {
                    res.status(400).send('Unable to update Terms of service');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    TermsOfService.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, termsofservice) => {
            if (err) res.json(err);
            else res.json('Terms of service successfully removed');
        },
    );
});

export default router;
