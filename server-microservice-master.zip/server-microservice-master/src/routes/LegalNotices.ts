import express from 'express';
const router = express.Router();

// Require LegalNotices model in our routes module
import LegalNotices from '../models/LegalNotices';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    LegalNotices.find((err, legalnoticess) => {
        if (err) {
            res.json(err);
        } else {
            res.json(legalnoticess);
        }
    });
});

// Defined get latest data(index or listing) route

router.route('/latest').get((req, res) => {
    LegalNotices.findOne()
        .sort({ _id: -1 })
        .limit(1)
        .exec((err, legalnotices) => {
            if (err) {
                res.json(err);
            } else {
                res.json(legalnotices);
            }
        });
});

// Defined store route
router.route('/').post((req, res) => {
    const legalnotices = new LegalNotices(req.body);

    legalnotices
        .save()
        .then(() => {
            res.status(200).json({
                message: 'LegalNotices successfully created',
            });
        })
        .catch(() => {
            res.status(400).send('Unable to create LegalNotices');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    LegalNotices.findById(id, (err, legalnotices) => {
        if (err) {
            res.json(err);
        }
        res.json(legalnotices);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    LegalNotices.findById(req.params.id, (err, legalnotices) => {
        if (!legalnotices) res.status(404).send('data is not found');
        else {
            legalnotices.content = req.body.content;
            legalnotices
                .save()
                .then(() => {
                    res.json('LegalNotices updated successfully');
                })
                .catch(() => {
                    res.status(400).send('Unable to update LegalNotices');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    LegalNotices.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, legalnotices) => {
            if (err) res.json(err);
            else res.json('LegalNotices successfully removed');
        },
    );
});

export default router;
