import express from 'express';
const router = express.Router();

// Require Event model in our routes
import Event from '../models/Event';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    Event.find((err, events) => {
        if (err) {
            res.json(err);
        } else {
            res.json(events);
        }
    });
});

// Retrieves a event based on the ID
router.route('/:id').get((req, res) => {
    const id = req.params.id
    Event.findById(id, (err, event) => {
        if (err) {
            console.log(`Error fetching event based on id ${id}: ${err}`)
            return res.json(err)
        } else {
            return res.status(200).json(event)
        }
    })
})

// Defined store route
router.route('/').post((req, res) => {
    const event = new Event(req.body);

    event
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Event successfully created',
            });
        })
        .catch((error) => {
            console.log('Error creating event', error)
            res.status(400).send('Unable to create Event');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    Event.findById(id, (err, event) => {
        if (err) {
            res.json(err);
        }
        res.json(event);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    Event.findById(req.params.id, (err, event) => {
        if (!event) res.status(404).send('data is not found');
        else {
            event.eventName = req.body.eventName;
            event.eventId = req.body.eventId;
            event.description = req.body.description;
            event.entryCriteria = req.body.entryCriteria;
            event.sponsorshipDetails = req.body.sponsorshipDetails;
            event.dateTime = req.body.dateTime;
            event
                .save()
                .then(() => {
                    res.json('Event updated successfully');
                })
                .catch(() => {
                    res.status(400).send('Unable to update Event');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    Event.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, event) => {
            if (err) res.json(err);
            else res.json('Event successfully removed');
        },
    );
});

export default router;
