import express from 'express';
const router = express.Router();

// Require User model in our routes module
import User from '../models/User';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    User.find((err, users) => {
        if (err) {
            res.json(err);
        } else {
            res.json(users);
        }
    });
});

// Defined store route
router.route('/').post((req, res) => {
    const user = new User(req.body);

    user.save()
        .then(() => {
            res.status(200).json({
                message: 'User successfully created',
            });
        })
        .catch(err => {
            res.status(400).send('Unable to create User ' + err);
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    User.findById(id, (err, user) => {
        if (err) {
            res.json(err);
        }
        res.json(user);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    User.findById(req.params.id, (err, user) => {
        if (!user) res.status(404).send('data is not found');
        else {
            user.username = req.body.username;
            user.password = req.body.password;
            user.role_id = req.body.role_id;
            // should not be editable
            user.profile_id = req.body.profile_id;
            user.setting_id = req.body.setting_id;
            user.save()
                .then(() => {
                    res.json('User updated successfully');
                })
                .catch(err => {
                    res.status(400).send('Unable to update User ' + err);
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    User.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, user) => {
            if (err) res.json(err);
            else res.json('User successfully removed');
        },
    );
});

export default router;
