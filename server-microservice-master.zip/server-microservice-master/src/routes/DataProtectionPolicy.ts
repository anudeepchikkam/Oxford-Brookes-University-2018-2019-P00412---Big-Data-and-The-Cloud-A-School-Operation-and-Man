import express from 'express';
const router = express.Router();

// Require DataProtectionPolicy model in our routes module
import DataProtectionPolicy from '../models/DataProtectionPolicy';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    DataProtectionPolicy.find((err, dataprotectionpolicies) => {
        if (err) {
            res.json(err);
        } else {
            res.json(dataprotectionpolicies);
        }
    });
});

// Defined get latest data(index or listing) route

router.route('/latest').get((req, res) => {
    DataProtectionPolicy.findOne()
        .sort({ _id: -1 })
        .limit(1)
        .exec((err, dataprotectionpolicy) => {
            if (err) {
                res.json(err);
            } else {
                res.json(dataprotectionpolicy);
            }
        });
});

// Defined store route
router.route('/').post((req, res) => {
    const dataprotectionpolicy = new DataProtectionPolicy(req.body);

    dataprotectionpolicy
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Data Protection Policy successfully created',
            });
        })
        .catch(() => {
            res.status(400).send('Unable to create Data Protection Policy');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    DataProtectionPolicy.findById(id, (err, dataprotectionpolicy) => {
        if (err) {
            res.json(err);
        }
        res.json(dataprotectionpolicy);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    DataProtectionPolicy.findById(req.params.id, (err, dataprotectionpolicy) => {
        if (!dataprotectionpolicy) res.status(404).send('data is not found');
        else {
            dataprotectionpolicy.content = req.body.content;
            dataprotectionpolicy
                .save()
                .then(() => {
                    res.json('Data Protection Policy updated successfully');
                })
                .catch(() => {
                    res.status(400).send('Unable to update Data Protection Policy');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    DataProtectionPolicy.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, dataprotectionpolicy) => {
            if (err) res.json(err);
            else res.json('Data Protection Policy successfully removed');
        },
    );
});

export default router;
