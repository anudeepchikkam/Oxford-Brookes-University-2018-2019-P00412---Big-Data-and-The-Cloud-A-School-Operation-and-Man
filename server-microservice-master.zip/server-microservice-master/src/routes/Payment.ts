import express from 'express';
const router = express.Router();

// Require Payment model in our routes module
import Payment from '../models/Payment';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    Payment.find((err, payments) => {
        if (err) {
            res.json(err);
        } else {
            res.json(payments);
        }
    });
});

// Defined store route
router.route('/').post((req, res) => {
    const payment = new Payment(req.body);

    payment
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Payment successfully created',
            });
        })
        .catch(err => {
            res.status(400).send('Unable to create Payment ' + err);
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    Payment.findById(id, (err, payment) => {
        if (err) {
            res.json(err);
        }
        res.json(payment);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    Payment.findById(req.params.id, (err, payment) => {
        if (!payment) res.status(404).send('data is not found');
        else {
            payment.user_id = req.body.user_id;
            payment.date = req.body.date;
            payment.operation = req.body.operation;
            payment.status = req.body.status;
            payment.debit = req.body.debit;
            payment.credit = req.body.credit;
            payment
                .save()
                .then(() => {
                    res.json('Payment updated successfully');
                })
                .catch(err => {
                    console.log(err);
                    res.status(400).send('Unable to update Payment ' + err);
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    Payment.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, payment) => {
            if (err) res.json(err);
            else res.json('Payment successfully removed');
        },
    );
});

export default router;
