import express from 'express';
const router = express.Router();

// Require CookiesPolicy model in our routes module
import CookiesPolicy from '../models/CookiesPolicy';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    CookiesPolicy.find((err, cookiepolicies) => {
        if (err) {
            res.json(err);
        } else {
            res.json(cookiepolicies);
        }
    });
});

// Defined get latest data(index or listing) route

router.route('/latest').get((req, res) => {
    CookiesPolicy.findOne()
        .sort({ _id: -1 })
        .limit(1)
        .exec((err, cookiepolicy) => {
            if (err) {
                res.json(err);
            } else {
                res.json(cookiepolicy);
            }
        });
});

// Defined store route
router.route('/').post((req, res) => {
    const cookiepolicy = new CookiesPolicy(req.body);

    cookiepolicy
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Cookies Policy successfully created',
            });
        })
        .catch(() => {
            res.status(400).send('Unable to create Cookies Policy');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    CookiesPolicy.findById(id, (err, cookiepolicy) => {
        if (err) {
            res.json(err);
        }
        res.json(cookiepolicy);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    CookiesPolicy.findById(req.params.id, (err, cookiepolicy) => {
        if (!cookiepolicy) res.status(404).send('data is not found');
        else {
            cookiepolicy.content = req.body.content;
            cookiepolicy
                .save()
                .then(() => {
                    res.json('Cookies Policy updated successfully');
                })
                .catch(() => {
                    res.status(400).send('Unable to update Cookies Policy');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    CookiesPolicy.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, cookiepolicy) => {
            if (err) res.json(err);
            else res.json('Cookies Policy successfully removed');
        },
    );
});

export default router;
