import express from 'express';
const router = express.Router();

// Require Role model in our routes module
import Role from '../models/Role';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    Role.find((err, roles) => {
        if (err) {
            res.json(err);
        } else {
            res.json(roles);
        }
    });
});

// Defined store route
router.route('/').post((req, res) => {
    const role = new Role(req.body);

    role.save()
        .then(() => {
            res.status(200).json({
                message: 'Role successfully created',
            });
        })
        .catch(() => {
            res.status(400).send('Unable to create Role');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    Role.findById(id, (err, role) => {
        if (err) {
            res.json(err);
        }
        res.json(role);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    Role.findById(req.params.id, (err, role) => {
        if (!role) res.status(404).send('data is not found');
        else {
            role.slug = req.body.slug;
            role.name = req.body.name;
            role.permissions = req.body.permissions;
            role.save()
                .then(() => {
                    res.json('Role updated successfully');
                })
                .catch(() => {
                    res.status(400).send('Unable to update Role');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    Role.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, role) => {
            if (err) res.json(err);
            else res.json('Role successfully removed');
        },
    );
});

export default router;
