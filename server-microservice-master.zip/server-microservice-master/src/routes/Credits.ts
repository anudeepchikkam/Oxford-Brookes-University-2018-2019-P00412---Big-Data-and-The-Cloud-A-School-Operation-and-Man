import express from 'express';
const router = express.Router();

// Require Credits model in our routes module
import Credits from '../models/Credits';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    Credits.find((err, creditss) => {
        if (err) {
            res.json(err);
        } else {
            res.json(creditss);
        }
    });
});

// Defined get latest data(index or listing) route

router.route('/latest').get((req, res) => {
    Credits.findOne()
        .sort({ _id: -1 })
        .limit(1)
        .exec((err, credits) => {
            if (err) {
                res.json(err);
            } else {
                res.json(credits);
            }
        });
});

// Defined store route
router.route('/').post((req, res) => {
    const credits = new Credits(req.body);

    credits
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Credits successfully created',
            });
        })
        .catch(() => {
            res.status(400).send('Unable to create Credits');
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    Credits.findById(id, (err, credits) => {
        if (err) {
            res.json(err);
        }
        res.json(credits);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    Credits.findById(req.params.id, (err, credits) => {
        if (!credits) res.status(404).send('data is not found');
        else {
            credits.content = req.body.content;
            credits
                .save()
                .then(() => {
                    res.json('Credits updated successfully');
                })
                .catch(() => {
                    res.status(400).send('Unable to update Credits');
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    Credits.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, credits) => {
            if (err) res.json(err);
            else res.json('Credits successfully removed');
        },
    );
});

export default router;
