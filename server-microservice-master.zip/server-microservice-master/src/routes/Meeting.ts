import express from 'express';
const router = express.Router();

// Require Meeting model in our routes meeting
import Meeting from '../models/Meeting';
import Invitation from '../models/Invitation';
import Profile from '../models/Profile';

// Import libaries
import { formatDate } from '../lib/Utils'

// Retrive meetings from database
router.route('/').get(async (req, res) => {
  const meetingData = await Meeting.aggregate([
    {
        $lookup: {
            from: "profiles",
            localField: "attendees",
            foreignField: "_id",
            as: "attendees"
        }
    }
], (err: any, payload: any) => {
    if (err) {
        console.log('Error fetching meetings and attendees profiles', err);
        return res.status(400).json(err);
    } else {
      return payload;
    }
  });

  const meetings = meetingData.map((x: any) => {
    return {
      _id: x._id,
      title: x.title,
      startDate: formatDate(x.startDate),
      endDate: formatDate(x.endDate),
      location: x.location,
      attendees: x.attendees,
      organiserId: x.organiserId,
      organiserProfile: {},
      description: x.description,
      typeOfMeeting: x.typeOfMeeting,
      inviteOnly: x.inviteOnly === true ? 'Yes' : 'No',
      createdAt: x.createdAt,
      updatedAt: x.updatedAt
    }
  });

  function getProfiles() {
    return meetings.map(async (x: any) => {
      const profilesPromises = await Profile.findById(x.organiserId);
      x.organiserProfile = profilesPromises;
      return x;
    })
  }
  const result = await getProfiles();

  Promise.all(result).then((data) => {
    return res.status(200).json(data);
  });
});

// Retrieves a meeting based on the ID
router.route('/:id').get((req, res) => {
  const id = req.params.id
  Meeting.findById(id, (err, meeting) => {
    if (err) {
      console.log(`Error fetching meeting based on id ${id}: ${err}`)
      return res.json(err)
  } else {
      return res.status(200).json(meeting)
    }
  })
})

// Defined store route
router.route('/').post(async (req, res) => {
  const meeting = new Meeting(req.body);
  const attendeesBody = req.body.attendees;
  const invitations = attendeesBody.map((x: any) => {
    return {
      meetingId: meeting._id,
      attendee: x,
      status: 'pending'
    }
  });

  let inv;

  meeting
    .save()
    .then((meet) => {
      console.log('Data saved', meet)
    })
    .catch((error) => {
      console.log('Error creating meeting', error);
      return res.status(400).send('Unable to create Meeting');
    });

    // Once the meeting is created, time to create the invitations
    // Due to some issue with MongoDB not being able to utilise `insertMany()` method to insert multiple documents, a JavaScript map function is used to achieve the same results
    invitations.map((zx: any) => {
      inv = new Invitation(zx);

      inv
      .save()
      .then((data) => {
        console.log('Invitation saved', data)
      })
      .catch((err: any) => {
        console.log('Error creating invitation', err);
        return res.status(400).send('Unable to create Invitation');
      })
    })

    return res.status(200).json({
      message: 'Meeting and Invitation created successfully'
    })
});

// Defined edit route
router.route('/:id').get((req, res) => {
  const id = req.params.id;
  Meeting.findById(id, (err, meeting) => {
    if (err) {
      console.log('Error fetching meeting', err);
      return res.status(400).json(err);
    }
    return res.status(200).json(meeting);
  });
});

//  Defined update route
router.route('/:id').post((req, res) => {
  Meeting.findById(req.params.id, (err, meeting) => {
    if (!meeting) {
      return res.status(404).send('data is not found');
    } else {
      meeting.title = req.body.title;
      meeting.startDate = req.body.startDate;
      meeting.endDate = req.body.endDate;
      meeting.location = req.body.location;
      meeting.organiserId = req.body.organiserId;
      meeting.attendees = req.body.attendees;
      meeting.description = req.body.description;
      meeting.typeOfMeeting = req.body.typeOfMeeting;
      meeting.inviteOnly = req.body.inviteOnly;

      meeting
      .save()
      .then(() => {
        return res.status(200).json('Meeting updated successfully');
      })
      .catch((error) => {
        console.log('Error updating Meeting', error);
        return res.status(400).send('Unable to update Meeting');
      });
    }
  });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
  Meeting.findByIdAndRemove({
    _id: req.params.id,
  }, (err, meeting) => {
          if (err) {
            console.log('Error deleting meeting', err);
            return res.status(400).json(err);
          } else {
            return res.status(200).json('Meeting successfully removed');
          }
      },
  );
});

export default router;
