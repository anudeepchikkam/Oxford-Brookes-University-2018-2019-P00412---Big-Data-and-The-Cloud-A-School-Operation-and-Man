import express from 'express';
const router = express.Router();

// Require Setting model in our routes module
import Setting from '../models/Setting';

// Defined get data(index or listing) route
router.route('/').get((req, res) => {
    Setting.find((err, settings) => {
        if (err) {
            res.json(err);
        } else {
            res.json(settings);
        }
    });
});

// Defined store route
router.route('/').post((req, res) => {
    const setting = new Setting(req.body);

    setting
        .save()
        .then(() => {
            res.status(200).json({
                message: 'Setting successfully created',
            });
        })
        .catch(err => {
            res.status(400).send('Unable to create Setting ' + err);
        });
});

// Defined edit route
router.route('/:id').get((req, res) => {
    const id = req.params.id;
    Setting.findById(id, (err, setting) => {
        if (err) {
            res.json(err);
        }
        res.json(setting);
    });
});

//  Defined update route
router.route('/:id').post((req, res) => {
    Setting.findById(req.params.id, (err, setting) => {
        if (!setting) res.status(404).send('data is not found');
        else {
            setting.user_id = req.body.user_id;
            setting.language_id = req.body.language_id;
            setting.contact_chat = req.body.contact_chat;
            setting.contact_email = req.body.contact_email;
            setting.contact_phone = req.body.contact_phone;
            setting.contact_sms = req.body.contact_sms;
            setting.notification_dashboard = req.body.notification_dashboard;
            setting.notification_email = req.body.notification_email;
            setting.notification_phone = req.body.notification_phone;
            setting.notification_push = req.body.notification_push;
            setting.notification_sms = req.body.notification_sms;
            setting
                .save()
                .then(() => {
                    res.json('Setting updated successfully');
                })
                .catch(err => {
                    res.status(400).send('Unable to update Setting ' + err);
                });
        }
    });
});

// Defined delete | remove | destroy route
router.route('/:id').delete((req, res) => {
    Setting.findByIdAndRemove(
        {
            _id: req.params.id,
        },
        (err, setting) => {
            if (err) res.json(err);
            else res.json('Setting successfully removed');
        },
    );
});

export default router;
