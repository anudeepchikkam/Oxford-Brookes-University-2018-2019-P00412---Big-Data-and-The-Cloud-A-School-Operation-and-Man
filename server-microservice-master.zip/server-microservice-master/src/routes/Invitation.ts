import express from 'express';
const router = express.Router();

// Require Invitation model in our routes invitation
import Invitation from '../models/Invitation';

import Meeting from '../models/Meeting';

// Import libaries
import { formatDate } from '../lib/Utils'

// Retrive meetings from database
router.route('/').get(async (req, res) => {
  Invitation.aggregate([
    {
        $lookup: {
            from: "profiles",
            localField: "attendee",
            foreignField: "_id",
            as: "attendeeDetails"
        }
    }
], async (err: any, payload: any) => {
    if (err) {
        console.log('Error fetching meetings and attendees profiles', err);
        return res.status(400).json(err);
    } else {
      function getMeetingInfo() {
        return payload.map(async (x: any) => {
          const meeting = await Meeting.findById(x.meetingId);
          x.meetingInfo = meeting;
          return x;
        })
      }
      const meetings = await getMeetingInfo();
    
      Promise.all(meetings).then((data) => {
        return res.status(200).json(data);
      });
    }
  });
});

export default router;
