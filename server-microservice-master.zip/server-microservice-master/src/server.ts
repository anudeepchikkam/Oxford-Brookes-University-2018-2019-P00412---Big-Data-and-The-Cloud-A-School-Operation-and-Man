/**
 * Server.ts
 * The main TypeScript file that intiates the API application with connecting to 
 * the database instance and configuring the API to accept various control options
 */

// Import Express framework, other libraries and user type routes
import express from 'express';
import bodyParser from 'body-parser';
import expressValidator from 'express-validator';
import cors from 'cors';
import mongoose from 'mongoose';
import morgan from 'morgan';
import dotenv from 'dotenv';
import APP from './config/app';
import DB from './config/db';
import About from './routes/About';
import Account from './routes/Account';
import CookiesPolicy from './routes/CookiesPolicy';
import Credits from './routes/Credits';
import Event from './routes/Event';
import DataProtectionPolicy from './routes/DataProtectionPolicy';
import LegalNotices from './routes/LegalNotices';
import Module from './routes/Module';
import Payment from './routes/Payment';
import Permission from './routes/Permission';
import Post from './routes/Post';
import Profile from './routes/Profile';
import Role from './routes/Role';
import Setting from './routes/Setting';
import TermsOfService from './routes/TermsOfService';
import User from './routes/User';
import Meeting from './routes/Meeting';
import Invitation from './routes/Invitation';

// Create an Express instance and declare the API Port
const app = express();
const PORT = APP.PORT;

dotenv.config();

// Connect to the MongoDB via Mongoose ORM
mongoose.Promise = global.Promise;
mongoose.connect(DB.URI, { useCreateIndex: true, useNewUrlParser: true }).then(
    () => {
        console.log('Database is connected');
    },
    err => {
        console.log('Can not connect to the database' + err);
    },
);

// options for cors midddleware
const options: cors.CorsOptions = {
    allowedHeaders: ['Origin', 'X-Requested-With', 'Content-Type', 'Accept', 'X-Access-Token'],
    credentials: true,
    methods: 'GET,HEAD,OPTIONS,PUT,PATCH,POST,DELETE',
    origin: [APP.URI, 'http://localhost:4000', 'http://localhost:8080', '*'],
    optionsSuccessStatus: 200,
    preflightContinue: false,
};

// support application/json type post data
app.use(express.json());
app.use(bodyParser.json());

// support application/x-www-form-urlencoded post data
app.use(bodyParser.urlencoded({ extended: true }));
app.use(expressValidator());

// use cors middleware
app.use(cors(options));
app.use(morgan('combined'));

//enable pre-flight
app.options('*', cors(options));

app.use(process.env.API_BASE + 'abouts', About);
app.use(process.env.API_BASE + 'accounts', Account);
app.use(process.env.API_BASE + 'cookies-policies', CookiesPolicy);
app.use(process.env.API_BASE + 'credits', Credits);
app.use(process.env.API_BASE + 'data-protection-policies', DataProtectionPolicy);
app.use(process.env.API_BASE + 'events', Event);
app.use(process.env.API_BASE + 'legal-notices', LegalNotices);
app.use(process.env.API_BASE + 'modules', Module);
app.use(process.env.API_BASE + 'payments', Payment);
app.use(process.env.API_BASE + 'permissions', Permission);
app.use(process.env.API_BASE + 'posts', Post);
app.use(process.env.API_BASE + 'profiles', Profile);
app.use(process.env.API_BASE + 'roles', Role);
app.use(process.env.API_BASE + 'settings', Setting);
app.use(process.env.API_BASE + 'terms-of-services', TermsOfService);
app.use(process.env.API_BASE + 'users', User);
app.use(process.env.API_BASE + 'meetings', Meeting);
app.use(process.env.API_BASE + 'invitations', Invitation);

// Listen in on the port to run the server
app.listen(PORT, () => {
    console.log('Server is running on Port:', PORT);
});
