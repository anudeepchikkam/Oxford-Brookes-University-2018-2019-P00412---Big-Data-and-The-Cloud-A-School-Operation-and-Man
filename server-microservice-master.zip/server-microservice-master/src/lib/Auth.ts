/**
 * The authentication library to create access tokens with JSON Web Token
 */
import * as _ from 'lodash'
import * as JWT from 'jsonwebtoken'

const config = {
  secret: 'ngEurope rocks!',
  audience: 'nodejs-jwt-auth',
  issuer: 'https://gonto.com'
}

// Creates a JSON Web Token that will authenticate the user to login to the system
export function createIdToken (user: any) {
  return JWT.sign(_.omit(user, 'password'), config.secret, { expiresIn: 60 * 60 * 5 })
}

// Creates an Access Token for validation purposes
export function createAccessToken () {
  return JWT.sign({
    iss: config.issuer,
    aud: config.audience,
    exp: Math.floor(Date.now() / 1000) + (60 * 60),
    scope: 'full_access',
    sub: 'lalaland|gonto',
    jti: genJti(), // unique identifier for the token
    alg: 'HS256'
  }, config.secret)
}

// Generate Unique Identifier for the access token
export function genJti () {
  let jti = ''
  const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  for (let i = 0; i < 16; i++) {
    jti += possible.charAt(Math.floor(Math.random() * possible.length))
  }
  return jti
}

export function getUserScheme (req: any) {
  let username
  let type
  let userSearch = {}

  // The POST contains a username and not an email
  if (req.body.payload.username) {
    username = req.body.payload.username
    type = 'username'
    userSearch = {
      username: username
    }
  } else if (req.body.payload.email) { // The POST contains an email and not an username
    username = req.body.payload.email
    type = 'email'
    userSearch = {
      email: username
    }
  }

  return {
    username: username,
    type: type,
    userSearch: userSearch
  }
}

