/**
 * Utility library to perform exhaustive operations
 */

// Formats the date and returns the value in Datetime
export function formatDate(date: any) {
  const dates = new Date(date);
  let hours: any = dates.getHours();
  let minutes: any = dates.getMinutes();
  let ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  let strTime = hours + ':' + minutes + ' ' + ampm;
  
  return dates.getMonth()+1 + "/" + dates.getDate() + "/" + dates.getFullYear() + "  " + strTime;
}