/**
 * API configuration file
 */

import dotenv from 'dotenv';

dotenv.config();

const { APP_URL, APP_PORT, APP_KEY, JWT_SECRET } = process.env;

const APP = {
    URI: APP_URL + ':' + APP_PORT,
    URL: APP_URL,
    PORT: APP_PORT,
    SECRET: APP_KEY,
    JWT_SECRET: JWT_SECRET,
};

export default APP;
