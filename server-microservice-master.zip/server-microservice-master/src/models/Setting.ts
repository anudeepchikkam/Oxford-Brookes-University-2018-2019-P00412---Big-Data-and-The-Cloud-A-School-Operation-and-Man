import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import ISetting from '@/interfaces/ISetting';
import { Timestamp } from 'bson';

// Define collection and schema for Setting
const SettingSchema = new Schema(
    {
        user_id: { type: Schema.Types.ObjectId, ref: 'User', required: false },
        language_id: { type: Number, required: false },
        contact_chat: { type: Boolean, required: false },
        contact_email: { type: Boolean, required: false },
        contact_phone: { type: Boolean, required: false },
        contact_sms: { type: Boolean, required: false },
        notification_dashboard: { type: Boolean, required: false },
        notification_email: { type: Boolean, required: false },
        notification_phone: { type: Boolean, required: false },
        notification_push: { type: Boolean, required: false },
        notification_sms: { type: Boolean, required: false },
    },
    {
        timestamps: true,
        collection: 'settings',
    },
);

const Setting = mongoose.model<ISetting>('Setting', SettingSchema);

export default Setting;
