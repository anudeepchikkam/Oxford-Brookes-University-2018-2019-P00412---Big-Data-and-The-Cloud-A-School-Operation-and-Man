import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IPermission from '@/interfaces/IPermission';
import { Timestamp } from 'bson';

// Define collection and schema for Permission
const PermissionSchema = new Schema(
    {
        slug: { type: String, required: true, unique: true },
        name: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'permissions',
    },
);

const Permission = mongoose.model<IPermission>('Permission', PermissionSchema);

export default Permission;
