import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import ICookiesPolicy from '@/interfaces/ICookiesPolicy';
import { Timestamp } from 'bson';

// Define collection and schema for Cookies Policy
const CookiesPolicySchema = new Schema(
    {
        content: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'cookies_policies',
    },
);

const CookiesPolicy = mongoose.model<ICookiesPolicy>('CookiesPolicy', CookiesPolicySchema);

export default CookiesPolicy;
