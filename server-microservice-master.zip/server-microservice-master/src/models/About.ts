import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IAbout from '@/interfaces/IAbout';
import { Timestamp } from 'bson';

// Define collection and schema for About
const AboutSchema = new Schema(
    {
        content: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'abouts',
    },
);

const About = mongoose.model<IAbout>('About', AboutSchema);

export default About;
