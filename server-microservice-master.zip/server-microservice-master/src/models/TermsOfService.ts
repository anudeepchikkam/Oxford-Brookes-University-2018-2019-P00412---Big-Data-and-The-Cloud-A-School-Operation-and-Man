import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import ITermsOfService from '@/interfaces/ITermsOfService';
import { Timestamp } from 'bson';

// Define collection and schema for Terms of Service
const TermsOfServiceSchema = new Schema(
    {
        content: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'terms_of_services',
    },
);

const TermsOfService = mongoose.model<ITermsOfService>('TermsOfService', TermsOfServiceSchema);

export default TermsOfService;
