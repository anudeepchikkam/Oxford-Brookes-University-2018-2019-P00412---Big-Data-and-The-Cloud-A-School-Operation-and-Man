import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IEvent from '@/interfaces/IEvent';
import { Timestamp } from 'bson';

// Define collection and schema for Event
const EventSchema = new Schema(
    {
        eventName: { type: String, required: true },
        eventId: { type: String, required: true },
        description: { type: String, required: true },
        entryCriteria: { type: String, required: true },
        sponsorshipDetails: { type: String, required: true },
        dateTime: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'event',
    },
);

const Event = mongoose.model<IEvent>('Event', EventSchema);

export default Event;





