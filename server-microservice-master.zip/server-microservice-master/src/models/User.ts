import mongoose from 'mongoose';
import * as bcrypt from 'bcryptjs';
import Schema = mongoose.Schema;
import IUser from '@/interfaces/IUser';
import { Timestamp } from 'bson';

// Define collection and schema for User
const UserSchema = new Schema(
    {
        username: {
            type: String,
            required: true,
            unique: true,
        },
        password: { type: String },
        role_id: { type: Schema.Types.ObjectId, ref: 'Role', required: true },
        profile_id: { type: Schema.Types.ObjectId, ref: 'Profile', required: false },
        setting_id: { type: Schema.Types.ObjectId, ref: 'Setting', required: false },
    },
    {
        timestamps: true,
        collection: 'users',
    },
);

// Hash the password before saving it to DB
UserSchema.pre<IUser>('save', function(next) {
    bcrypt.hash(this.password, 10, (err, hash) => {
        this.password = hash;
        next();
    });
});

// Re-hashing the password upon updating the password value before saving it to DB
UserSchema.pre<IUser>('update', function(next) {
    bcrypt.hash(this.password, 10, (err, hash) => {
        this.password = hash;
        next();
    });
});

const User = mongoose.model<IUser>('User', UserSchema);

export default User;
