import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IMeeting from '@/interfaces/IMeeting';
import { Timestamp } from 'bson';

// Define collection and schema for Meeting
const MeetingSchema = new Schema(
    {
        title: { type: String, required: true },
        startDate: { type: String, required: true },
        endDate: { type: String, required: true },
        location: { type: String, required: true },
        organiserId: { type: Schema.Types.ObjectId, ref: 'Profile', required: true },
        organiserProfile: {type: {}, required: false },
        attendees: { type: [Schema.Types.ObjectId], ref: 'Profile', required: false },
        description: { type: String, required: true },
        typeOfMeeting: { type: String, required: true },
        inviteOnly: { type: Boolean, required: true }
    },
    {
        timestamps: true,
        collection: 'meetings',
    },
);

const Meeting = mongoose.model<IMeeting>('Meeting', MeetingSchema);

export default Meeting;
