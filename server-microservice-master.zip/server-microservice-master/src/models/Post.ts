import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IPost from '@/interfaces/IPost';
import { Timestamp } from 'bson';

// Define collection and schema for Post
const PostSchema = new Schema(
    {
        title: { type: String, required: true },
        body: { type: String, required: true },
        user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    },
    {
        timestamps: true,
        collection: 'posts',
    },
);

const Post = mongoose.model<IPost>('Post', PostSchema);

export default Post;
