import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IInvitation from '@/interfaces/IInvitation';
import { Timestamp } from 'bson';

// Define collection and schema for Invitation
const InvitationSchema = new Schema(
    {
        meetingId: { type: Schema.Types.ObjectId, ref: 'Meeting', required: true },
        status: {type: String, required: true },
        attendee: { type: Schema.Types.ObjectId, ref: 'Meeting', required: true },
        attendeeDetails: { type: {}, required: false }
    },
    {
        timestamps: true,
        collection: 'invitations',
    },
);

const Invitation = mongoose.model<IInvitation>('Invitation', InvitationSchema);

export default Invitation;
