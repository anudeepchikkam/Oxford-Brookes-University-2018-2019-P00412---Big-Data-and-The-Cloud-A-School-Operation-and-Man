import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import ICredits from '@/interfaces/ICredits';
import { Timestamp } from 'bson';

// Define collection and schema for Credits
const CreditsSchema = new Schema(
    {
        content: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'credits',
    },
);

const Credits = mongoose.model<ICredits>('Credits', CreditsSchema);

export default Credits;
