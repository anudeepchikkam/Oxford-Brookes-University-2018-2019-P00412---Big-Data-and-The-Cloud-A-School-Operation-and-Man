import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IRole from '@/interfaces/IRole';
import { Timestamp } from 'bson';

// Define collection and schema for Role
const RoleSchema = new Schema(
    {
        slug: { type: String, required: true, unique: true },
        name: { type: String, required: true },
        permissions: [
            {
                ref: 'Permission',
                type: mongoose.Schema.Types.ObjectId,
                required: false,
            },
        ],
    },
    {
        timestamps: true,
        collection: 'roles',
    },
);

const Role = mongoose.model<IRole>('Role', RoleSchema);

export default Role;
