import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IDataProtectionPolicy from '@/interfaces/IDataProtectionPolicy';
import { Timestamp } from 'bson';

// Define collection and schema for Data Protection Policy
const DataProtectionPolicySchema = new Schema(
    {
        content: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'data_protection_policies',
    },
);

const DataProtectionPolicy = mongoose.model<IDataProtectionPolicy>('DataProtectionPolicy', DataProtectionPolicySchema);

export default DataProtectionPolicy;
