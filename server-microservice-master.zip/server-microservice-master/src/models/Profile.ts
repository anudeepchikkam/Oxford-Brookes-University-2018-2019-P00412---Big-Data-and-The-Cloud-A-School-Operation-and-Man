import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IProfile from '@/interfaces/IProfile';
import { Timestamp } from 'bson';

// Define collection and schema for Profile
const ProfileSchema = new Schema(
    {
        user_id: { type: Schema.Types.ObjectId, ref: 'User', required: false },
        first_name: { type: String, required: true },
        last_name: { type: String, required: true },
        phone: { type: Number, required: false },
        mobile: { type: Number, required: false },
        email: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'profiles',
    },
);

const Profile = mongoose.model<IProfile>('Profile', ProfileSchema);

export default Profile;
