import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IModule from '@/interfaces/IModule';
import { Timestamp } from 'bson';

// Define collection and schema for Module
const ModuleSchema = new Schema(
    {
        name: { type: String, required: true },
        yearGroup: { type: String, required: true },
        teacherName: { type: String, required: true },
        markingCriteria: { type: String, required: true },
        syllabus: { type: String, required: true },
    },
    {
        timestamps: true,
        collection: 'modules',
    },
);

const Module = mongoose.model<IModule>('Module', ModuleSchema);

export default Module;
