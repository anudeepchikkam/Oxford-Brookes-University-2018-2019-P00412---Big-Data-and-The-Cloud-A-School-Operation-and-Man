import mongoose from 'mongoose';
import Schema = mongoose.Schema;
import IPayment from '@/interfaces/IPayment';
import { Timestamp } from 'bson';

// Define collection and schema for Payment
const PaymentSchema = new Schema(
    {
        user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
        date: { type: Date, required: true },
        operation: { type: String, required: true },
        status: { type: Boolean, required: true },
        debit: { type: Number, required: false },
        credit: { type: Number, required: false },
    },
    {
        timestamps: true,
        collection: 'payments',
    },
);

const Payment = mongoose.model<IPayment>('Payment', PaymentSchema);

export default Payment;
