import mongoose from 'mongoose';
import IMeeting from './IMeeting';
import IProfile from './IProfile';
export default interface IInvitation extends mongoose.Document {
    meetingId: IMeeting['_id'];
    status: string;
    attendee: IMeeting['attendees'];
    attendeeDetails: object;
}
