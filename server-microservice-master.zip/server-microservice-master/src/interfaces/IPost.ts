import mongoose from 'mongoose';
import IUser from './IUser';

export default interface IPost extends mongoose.Document {
    title: string;
    body: string;
    user_id: IUser['_id'];
}
