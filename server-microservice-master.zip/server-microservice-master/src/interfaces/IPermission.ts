import mongoose from 'mongoose';

export default interface IPermission extends mongoose.Document {
    slug: string;
    name: string;
}
