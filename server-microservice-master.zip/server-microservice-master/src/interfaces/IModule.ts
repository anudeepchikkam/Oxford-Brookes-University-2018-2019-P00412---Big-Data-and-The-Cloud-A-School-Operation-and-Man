import mongoose from 'mongoose';

export default interface IModule extends mongoose.Document {
    name: string;
    yearGroup: string;
    teacherName: string;
    markingCriteria: string;
    syllabus: string;
}
