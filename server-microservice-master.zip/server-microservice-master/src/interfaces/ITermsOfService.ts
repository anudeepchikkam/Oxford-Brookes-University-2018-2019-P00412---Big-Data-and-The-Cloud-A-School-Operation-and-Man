import mongoose from 'mongoose';

export default interface ITermsOfService extends mongoose.Document {
    content: string;
}
