import mongoose from 'mongoose';

export default interface ILegalNotices extends mongoose.Document {
    content: string;
}
