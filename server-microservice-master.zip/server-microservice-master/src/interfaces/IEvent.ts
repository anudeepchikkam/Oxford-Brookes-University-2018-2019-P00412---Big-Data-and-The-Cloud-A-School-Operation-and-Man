import mongoose from 'mongoose';

export default interface IEvent extends mongoose.Document {
    
    eventName: string;
    eventId: string;
    description: string;
    entryCriteria: string;
    sponsorshipDetails: string;
    dateTime: string;

}
