import mongoose from 'mongoose';
import IPermission from './IPermission';

export default interface IRole extends mongoose.Document {
    slug: string;
    name: string;
    permissions: Array<IPermission['_id']>;
}
