import mongoose from 'mongoose';

export default interface ICredits extends mongoose.Document {
    content: string;
}
