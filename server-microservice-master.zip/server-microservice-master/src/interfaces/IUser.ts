import mongoose from 'mongoose';
import IProfile from './IProfile';
import IRole from './IRole';
import ISetting from './ISetting';
export default interface IUser extends mongoose.Document {
    username: string;
    password: string;
    role_id: IRole['_id'];
    profile_id: IProfile['_id'];
    setting_id: ISetting['_id'];
}
