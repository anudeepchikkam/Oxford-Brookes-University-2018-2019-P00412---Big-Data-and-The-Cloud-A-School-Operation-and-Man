import mongoose from 'mongoose';
import IProfile from './IProfile';
export default interface IMeeting extends mongoose.Document {
    title: string;
    startDate: string;
    endDate: string;
    location: string;
    organiserId: IProfile['_id'];
    organiserProfile: object;
    attendees: [IProfile['_id']];
    description: string;
    typeOfMeeting: string;
    inviteOnly: boolean;
}
