import mongoose from 'mongoose';
import { Timestamp } from 'bson';
import IUser from './IUser';

export default interface IProfile extends mongoose.Document {
    user_id: IUser['_id'];
    first_name: String;
    last_name: String;
    birthdate: Timestamp;
    phone: Number;
    mobile: Number;
    email: String;
}
