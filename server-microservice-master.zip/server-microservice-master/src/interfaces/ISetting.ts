import mongoose from 'mongoose';
import IUser from './IUser';

export default interface ISetting extends mongoose.Document {
    user_id: IUser['_id'];
    language_id: number;
    contact_chat: boolean;
    contact_email: boolean;
    contact_phone: boolean;
    contact_sms: boolean;
    notification_dashboard: boolean;
    notification_email: boolean;
    notification_phone: boolean;
    notification_push: boolean;
    notification_sms: boolean;
}
