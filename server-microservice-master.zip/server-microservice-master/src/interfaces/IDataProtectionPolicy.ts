import mongoose from 'mongoose';

export default interface IDataProtectionPolicy extends mongoose.Document {
    content: string;
}
