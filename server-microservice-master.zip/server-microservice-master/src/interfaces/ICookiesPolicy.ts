import mongoose from 'mongoose';

export default interface ICookiesPolicy extends mongoose.Document {
    content: string;
}
