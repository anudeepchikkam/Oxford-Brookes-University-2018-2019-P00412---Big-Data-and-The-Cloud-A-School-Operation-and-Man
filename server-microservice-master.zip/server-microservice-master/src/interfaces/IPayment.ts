import mongoose from 'mongoose';
import IUser from './IUser';

export default interface IPayment extends mongoose.Document {
    user_id: IUser['_id'];
    date: Date;
    operation: String;
    status: boolean;
    debit: number;
    credit: number;
}
