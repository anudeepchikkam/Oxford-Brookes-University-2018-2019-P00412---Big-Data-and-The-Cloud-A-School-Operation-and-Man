import mongoose from 'mongoose';

export default interface IAbout extends mongoose.Document {
    content: string;
}
