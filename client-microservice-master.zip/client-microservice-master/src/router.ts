/**
 * Routing library
 * This allows us to render view pages with the respective route paths that we want
 */

// Import Vue and Vue-Router library
import Vue from 'vue';
import Router from 'vue-router';

// Import View pages
import Contact from './views/Contact.vue';
import Home from './views/Home.vue';
import Dashboard from './views/Dashboard/Index.vue';
import Abouts from './views/Dashboard/Abouts/Index.vue';
import AboutsCreate from './views/Dashboard/Abouts/Create.vue';
import AboutsEdit from './views/Dashboard/Abouts/Edit.vue';
import Account from './views/Dashboard/Account.vue';
import Accounts from './views/Dashboard/Accounts/Index.vue';
import AccountsCreate from './views/Dashboard/Accounts/Create.vue';
import AccountsEdit from './views/Dashboard/Accounts/Edit.vue';
import Chats from './views/Dashboard/Chats/Index.vue';
import ChatsCreate from './views/Dashboard/Chats/Create.vue';
import ChatsEdit from './views/Dashboard/Chats/Edit.vue';
import CookiesPolicies from './views/Dashboard/CookiesPolicies/Index.vue';
import CookiesPoliciesCreate from './views/Dashboard/CookiesPolicies/Create.vue';
import CookiesPoliciesEdit from './views/Dashboard/CookiesPolicies/Edit.vue';
import CookiesPolicyLatest from './views/Legal/CookiesPolicy.vue';
import Credits from './views/Dashboard/Credits/Index.vue';
import CreditsCreate from './views/Dashboard/Credits/Create.vue';
import CreditsEdit from './views/Dashboard/Credits/Edit.vue';
import CreditsLatest from './views/Legal/Credits.vue';
import DataProtectionPolicies from './views/Dashboard/DataProtectionPolicies/Index.vue';
import DataProtectionPoliciesCreate from './views/Dashboard/DataProtectionPolicies/Create.vue';
import DataProtectionPoliciesEdit from './views/Dashboard/DataProtectionPolicies/Edit.vue';
import DataProtectionPolicyLatest from './views/Legal/DataProtectionPolicy.vue';
import Event from './views/Dashboard/Event.vue';
import Events from './views/Dashboard/Events/Index.vue';
import EventsCreate from './views/Dashboard/Events/Create.vue';
import EventsEdit from './views/Dashboard/Events/Edit.vue';
import LegalNotices from './views/Dashboard/LegalNotices/Index.vue';
import LegalNoticesCreate from './views/Dashboard/LegalNotices/Create.vue';
import LegalNoticesEdit from './views/Dashboard/LegalNotices/Edit.vue';
import LegalNoticesLatest from './views/Legal/LegalNotices.vue';
import Modules from './views/Dashboard/Modules/Index.vue';
import ModulesCreate from './views/Dashboard/Modules/Create.vue';
import ModulesEdit from './views/Dashboard/Modules/Edit.vue';
import Payment from './views/Dashboard/Payment.vue';
import Payments from './views/Dashboard/Payments/Index.vue';
import PaymentsCreate from './views/Dashboard/Payments/Create.vue';
import PaymentsEdit from './views/Dashboard/Payments/Edit.vue';
import Permissions from './views/Dashboard/Permissions/Index.vue';
import PermissionsCreate from './views/Dashboard/Permissions/Create.vue';
import PermissionsEdit from './views/Dashboard/Permissions/Edit.vue';
import Posts from './views/Dashboard/Posts/Index.vue';
import PostsCreate from './views/Dashboard/Posts/Create.vue';
import PostsEdit from './views/Dashboard/Posts/Edit.vue';
import Profile from './views/Dashboard/Profile.vue';
import Profiles from './views/Dashboard/Profiles/Index.vue';
import ProfilesCreate from './views/Dashboard/Profiles/Create.vue';
import ProfilesEdit from './views/Dashboard/Profiles/Edit.vue';
import Roles from './views/Dashboard/Roles/Index.vue';
import RolesCreate from './views/Dashboard/Roles/Create.vue';
import RolesEdit from './views/Dashboard/Roles/Edit.vue';
import Setting from './views/Dashboard/Setting.vue';
import Settings from './views/Dashboard/Settings/Index.vue';
import SettingsCreate from './views/Dashboard/Settings/Create.vue';
import SettingsEdit from './views/Dashboard/Settings/Edit.vue';
import TermsOfServices from './views/Dashboard/TermsOfServices/Index.vue';
import TermsOfServicesCreate from './views/Dashboard/TermsOfServices/Create.vue';
import TermsOfServicesEdit from './views/Dashboard/TermsOfServices/Edit.vue';
import TermsOfServiceLatest from './views/Legal/TermsOfService.vue';
import Users from './views/Dashboard/Users/Index.vue';
import UsersCreate from './views/Dashboard/Users/Create.vue';
import UsersEdit from './views/Dashboard/Users/Edit.vue';
import Invitations from './views/Invitation.vue';
import Meetings from './views/Dashboard/Meetings/Index.vue';
import MeetingsCreate from './views/Dashboard/Meetings/Create.vue';
import MeetingsEdit from './views/Dashboard/Meetings/Edit.vue';
import Login from './views/Login.vue';
import Register from './views/Register.vue';

Vue.use(Router);

export default new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    routes: [
        {
            path: '/',
            name: 'home',
            component: Home,
        },
        {
            path: '/about',
            name: 'about-latest',
            // route level code-splitting
            // this generates a separate chunk (about.[hash].js) for this route
            // which is lazy-loaded when the route is visited.
            component: () => import(/* webpackChunkName: "about" */ './views/About.vue'),
        },
        {
            path: '/dashboard/abouts',
            name: 'abouts',
            component: Abouts,
        },
        {
            path: '/dashboard/abouts/create',
            name: 'abouts-create',
            component: AboutsCreate,
        },
        {
            path: '/dashboard/abouts/:id/edit',
            name: 'abouts-edit',
            component: AboutsEdit,
        },
        {
            path: '/contact',
            name: 'contact',
            component: Contact,
        },
        {
            path: '/login',
            name: 'Login',
            component: Login,
        },
        {
            path: '/register',
            name: 'Register',
            component: Register,
        },
        {
            path: '/dashboard/account/:id',
            name: 'account',
            component: Account,
        },
        {
            path: '/dashboard/accounts',
            name: 'accounts',
            component: Accounts,
        },
        {
            path: '/dashboard/accounts/create',
            name: 'accounts-create',
            component: AccountsCreate,
        },
        {
            path: '/dashboard/accounts/:id/edit',
            name: 'accounts-edit',
            component: AccountsEdit,
        },
        {
            path: '/dashboard/chats',
            name: 'chats',
            component: Chats,
        },
        {
            path: '/dashboard/chats/create',
            name: 'chats-create',
            component: ChatsCreate,
        },
        {
            path: '/dashboard/chats/:id/edit',
            name: 'chats-edit',
            component: ChatsEdit,
        },
        {
            path: '/dashboard/cookies-policies',
            name: 'cookies-policies',
            component: CookiesPolicies,
        },
        {
            path: '/dashboard/cookies-policies/create',
            name: 'cookies-policies-create',
            component: CookiesPoliciesCreate,
        },
        {
            path: '/dashboard/cookies-policies/:id/edit',
            name: 'cookies-policies-edit',
            component: CookiesPoliciesEdit,
        },
        {
            path: '/cookies-policy',
            name: 'cookies-policy-latest',
            component: CookiesPolicyLatest,
        },
        {
            path: '/dashboard/credits',
            name: 'credits',
            component: Credits,
        },
        {
            path: '/dashboard/credits/create',
            name: 'credits-create',
            component: CreditsCreate,
        },
        {
            path: '/dashboard/credits/:id/edit',
            name: 'credits-edit',
            component: CreditsEdit,
        },
        {
            path: '/credits',
            name: 'credits-latest',
            component: CreditsLatest,
        },
        {
            path: '/dashboard',
            name: 'Dashboard',
            component: Dashboard,
        },
        {
            path: '/dashboard/data-protection-policies',
            name: 'data-protection-policies',
            component: DataProtectionPolicies,
        },
        {
            path: '/dashboard/data-protection-policies/create',
            name: 'data-protection-policies-create',
            component: DataProtectionPoliciesCreate,
        },
        {
            path: '/dashboard/data-protection-policies/:id/edit',
            name: 'data-protection-policies-edit',
            component: DataProtectionPoliciesEdit,
        },
        {
            path: '/data-protection-policies',
            name: 'data-protection-policy-latest',
            component: DataProtectionPolicyLatest,
        },
        {
            path: '/dashboard/event',
            name: 'event',
            component: Event,
        },
        {
            path: '/dashboard/events',
            name: 'events',
            component: Events,
        },
        {
            path: '/dashboard/events/create',
            name: 'events-create',
            component: EventsCreate,
        },
        {
            path: '/dashboard/events/:id/edit',
            name: 'events-edit',
            component: EventsEdit,
        },
        {
            path: '/dashboard/legal-notices',
            name: 'legal-notices',
            component: LegalNotices,
        },
        {
            path: '/dashboard/legal-notices/create',
            name: 'legal-notices-create',
            component: LegalNoticesCreate,
        },
        {
            path: '/dashboard/legal-notices/:id/edit',
            name: 'legal-notices-edit',
            component: LegalNoticesEdit,
        },
        {
            path: '/legal-notices',
            name: 'legal-notices-latest',
            component: LegalNoticesLatest,
        },
        {
            path: '/dashboard/modules',
            name: 'modules',
            component: Modules,
        },
        {
            path: '/dashboard/modules/create',
            name: 'modules-create',
            component: ModulesCreate,
        },
        {
            path: '/dashboard/modules/:id/edit',
            name: 'modules-edit',
            component: ModulesEdit,
        },
        {
            path: '/dashboard/payment',
            name: 'payment',
            component: Payment,
        },
        {
            path: '/dashboard/payments',
            name: 'payments',
            component: Payments,
        },
        {
            path: '/dashboard/payments/create',
            name: 'payments-create',
            component: PaymentsCreate,
        },
        {
            path: '/dashboard/payments/:id/edit',
            name: 'payments-edit',
            component: PaymentsEdit,
        },
        {
            path: '/dashboard/permissions',
            name: 'permissions',
            component: Permissions,
        },
        {
            path: '/dashboard/permissions/create',
            name: 'permissions-create',
            component: PermissionsCreate,
        },
        {
            path: '/dashboard/permissions/:id/edit',
            name: 'permissions-edit',
            component: PermissionsEdit,
        },
        {
            path: '/dashboard/posts',
            name: 'posts',
            component: Posts,
        },
        {
            path: '/dashboard/posts/create',
            name: 'posts-create',
            component: PostsCreate,
        },
        {
            path: '/dashboard/posts/:id/edit',
            name: 'posts-edit',
            component: PostsEdit,
        },
        {
            path: '/dashboard/:id/profile',
            name: 'profile',
            component: Profile,
        },
        {
            path: '/dashboard/profiles',
            name: 'profiles',
            component: Profiles,
        },
        {
            path: '/dashboard/profiles/create',
            name: 'profiles-create',
            component: ProfilesCreate,
        },
        {
            path: '/dashboard/profiles/:id/edit',
            name: 'profiles-edit',
            component: ProfilesEdit,
        },
        {
            path: '/dashboard/roles',
            name: 'roles',
            component: Roles,
        },
        {
            path: '/dashboard/roles/create',
            name: 'roles-create',
            component: RolesCreate,
        },
        {
            path: '/dashboard/roles/:id/edit',
            name: 'roles-edit',
            component: RolesEdit,
        },
        {
            path: '/dashboard/:id/setting/',
            name: 'setting',
            component: Setting,
        },
        {
            path: '/dashboard/settings',
            name: 'settings',
            component: Settings,
        },
        {
            path: '/dashboard/settings/create',
            name: 'settings-create',
            component: SettingsCreate,
        },
        {
            path: '/dashboard/settings/:id/edit',
            name: 'settings-edit',
            component: SettingsEdit,
        },
        {
            path: '/dashboard/terms-of-services',
            name: 'terms-of-services',
            component: TermsOfServices,
        },
        {
            path: '/dashboard/terms-of-services/create',
            name: 'terms-of-services-create',
            component: TermsOfServicesCreate,
        },
        {
            path: '/dashboard/terms-of-services/:id/edit',
            name: 'terms-of-services-edit',
            component: TermsOfServicesEdit,
        },
        {
            path: '/terms-of-services',
            name: 'terms-of-service-latest',
            component: TermsOfServiceLatest,
        },
        {
            path: '/dashboard/users',
            name: 'users',
            component: Users,
        },
        {
            path: '/dashboard/users/create',
            name: 'users-create',
            component: UsersCreate,
        },
        {
            path: '/dashboard/users/:id/edit',
            name: 'users-edit',
            component: UsersEdit,
        },
        {
            path: '/dashboard/invitations',
            name: 'invitations',
            component: Invitations,
        },
        {
            path: '/dashboard/meetings',
            name: 'meetings',
            component: Meetings,
        },
        {
            path: '/dashboard/meetings/create',
            name: 'meetings-create',
            component: MeetingsCreate,
        },
        {
            path: '/dashboard/meetings/:id/edit',
            name: 'meetings-edit',
            component: MeetingsEdit,
        },
    ],
});
