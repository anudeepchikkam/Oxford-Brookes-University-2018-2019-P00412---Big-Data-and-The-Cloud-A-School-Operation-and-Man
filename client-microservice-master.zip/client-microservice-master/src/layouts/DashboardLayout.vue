<template>
  <div class="DashboardLayout">
    <!-- <b-row>
      <b-col cols="1">
        <sidebar/>
      </b-col>

      <b-col cols="11">
        <b-row>
          <navbar/>
        </b-row>
        <b-row>
          dsakjdslakdsaldksldakdlsakdldksldka
          <router-view/>
        </b-row>
      </b-col>
    </b-row> -->
  </div>
</template>

<script lang="ts">
// import Navbar from "@/components/Dashboard/Navbar.vue";
// import Sidebar from "@/components/Dashboard/Sidebar.vue";

export default {
  name: "DashboardLayout",
  components: {
    // Navbar,
    // Sidebar
  }
};
</script>
