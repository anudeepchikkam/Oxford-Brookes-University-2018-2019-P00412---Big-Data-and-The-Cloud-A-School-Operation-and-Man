import Vue from 'vue';
import Vuex from 'vuex';

// Use state management
Vue.use(Vuex);

// Exports the store state to be used in the main.ts file
export default new Vuex.Store({ state: {}, mutations: {}, actions: {} });
