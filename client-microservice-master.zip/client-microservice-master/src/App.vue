<template>
  <div id="app">
    <navbar/>
    <div class="container-fluid">
      <div class="row">
        <b-navbar toggleable="lg">
          <b-collapse is-nav>
            <sidebar/>
          </b-collapse>
        </b-navbar>
        <div role="main" class="col-xs-9 ml-auto col-md-10 px-4 my-3">
          <transition name="slide-fade">
            <router-view></router-view>
          </transition>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Navbar from '@/components/Navbar.vue';
import Sidebar from '@/components/Sidebar.vue';

export default {
    name: 'app',
    components: {
        Navbar,
        Sidebar,
    },
    data() {
        return {};
    },

    created() {},

    methods: {},
};
</script>

<style lang="scss">
.slide-fade-enter-active {
    transition: all 0.4s ease;
}
.slide-fade-leave-active {
    transition: all 0.2s cubic-bezier(1, 0.5, 0.8, 1);
}
.slide-fade-enter,
.slide-fade-leave-to {
    transform: translateX(10px);
    opacity: 0;
}
</style>