<template>
<div>
  <frontend-layout>
    <div class="home text-center my-3">
      <img alt="homelogo" class="img-fluid home-img my-4" src="../assets/school.svg">
      <h1>Welcome to<br>A School Operation And Management System</h1>
      <h2><i>Also known as ASOAMS</i></h2>
    </div>
  </frontend-layout>
</div>
</template>

<script>
import { Component, Vue } from "vue-property-decorator";
import FrontendLayout from "@/layouts/FrontendLayout.vue";

@Component({
  components: {
    FrontendLayout,
    // HelloWorld
  }
})
export default class Home extends Vue {}
</script>
