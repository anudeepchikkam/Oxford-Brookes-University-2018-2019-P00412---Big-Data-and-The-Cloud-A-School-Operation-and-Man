<template>
  <div class="about">
    <h1>About</h1>
    <div>Last update: {{ about.updatedAt }}</div>
    <div>{{ about.content }}</div>
  </div>
</template>
<script>
export default {
    data() {
        return {
            about: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/abouts/latest`;

        this.axios.get(uri).then(response => {
            this.about = response.data;
        });
    },
};
</script>