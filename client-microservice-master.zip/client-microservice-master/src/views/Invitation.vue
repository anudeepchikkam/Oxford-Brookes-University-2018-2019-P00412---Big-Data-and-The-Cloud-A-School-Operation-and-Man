<template>
<div class="container">
  <h1>Invitations</h1>
  <b-card v-for="(invite, index) in orderInvitations" :key="index" class="my-3">
    <b-row>
      <b-col md="10">
        <p v-if="invite.status === 'pending'" class="btn btn-warning text-white">Accept Pending</p>
        <p v-if="invite.status === 'accepted'" class="btn btn-success text-white">Accepted</p>
        <p v-if="invite.status === 'declined'" class="btn btn-danger text-white">Declined</p>
        <b-card-title>Title: {{ invite.meetingInfo.title }}</b-card-title>
        <b-card-text><fa-icon icon="map-marker-alt" fixed-width/> {{ invite.meetingInfo.location }}</b-card-text>
        <b-card-text><fa-icon icon="align-left" fixed-width/> {{ invite.meetingInfo.description }}</b-card-text>
        <!-- <b-card-title v-for="(attendee, indexA) in invite.attendeeDetails" :key="indexA">{{ `${attendee.first_name} ${attendee.last_name}` }}</b-card-title> -->
      </b-col>
      <b-col md="2">
        <b-button variant="success" class="my-3 px-3 w-100">Accept</b-button>
        <b-button variant="danger" class="px-3 w-100">Decline</b-button>
      </b-col>
    </b-row>
  </b-card>

</div>

</template>
<script>
// Import library
import _ from 'lodash';

export default {
  data() {
    return {
      invitations: []
    };
  },
  created() {
    const invitationUrl = 'http://localhost:4000/api/invitations';

    this.axios.get(invitationUrl).then(response => {
      this.invitations = response.data;
    })
    .catch((error) => {
      console.log('Error fetching invitations', error)
    });
  },
  computed: {
    orderInvitations: function () {
      return _.orderBy(this.invitations, 'createdAt', 'desc')
    }
  },
  methods: {
  } 
};
</script>