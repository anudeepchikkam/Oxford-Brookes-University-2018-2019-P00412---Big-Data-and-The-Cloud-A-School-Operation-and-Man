<template>
  <div class="cookies-policy">
    <h1>Cookies policy</h1>
    <div>Last update: {{ cookiespolicy.updatedAt }}</div>
    <div>{{ cookiespolicy.content }}</div>
  </div>
</template>
<script>
export default {
    data() {
        return {
            cookiespolicy: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/cookies-policies/latest`;

        this.axios.get(uri).then(response => {
            this.cookiespolicy = response.data;
        });
    },
};
</script>