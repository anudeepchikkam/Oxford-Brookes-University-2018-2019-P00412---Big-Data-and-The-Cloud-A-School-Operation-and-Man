<template>
  <div class="terms-of-service">
    <h1>Terms of Service</h1>
    <div>Last update: {{ termsofservice.updatedAt }}</div>
    <div>{{ termsofservice.content }}</div>
  </div>
</template>
<script>
export default {
    data() {
        return {
            termsofservice: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/terms-of-services/latest`;

        this.axios.get(uri).then(response => {
            this.termsofservice = response.data;
        });
    },
};
</script>