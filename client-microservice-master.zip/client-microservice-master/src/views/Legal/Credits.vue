<template>
  <div class="credits">
    <h1>Credits</h1>
    <div>Last update: {{ credits.updatedAt }}</div>
    <div>{{ credits.content }}</div>
  </div>
</template>
<script>
export default {
    data() {
        return {
            credits: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/credits/latest`;

        this.axios.get(uri).then(response => {
            this.credits = response.data;
        });
    },
};
</script>