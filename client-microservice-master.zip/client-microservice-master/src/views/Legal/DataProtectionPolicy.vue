<template>
  <div class="data-protection-policy">
    <h1>Data Protection policy</h1>
    <div>Last update: {{ dataprotectionpolicy.updatedAt }}</div>
    <div>{{ dataprotectionpolicy.content }}</div>
  </div>
</template>
<script>
export default {
    data() {
        return {
            dataprotectionpolicy: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/data-protection-policy/latest`;

        this.axios.get(uri).then(response => {
            this.dataprotectionpolicy = response.data;
        });
    },
};
</script>