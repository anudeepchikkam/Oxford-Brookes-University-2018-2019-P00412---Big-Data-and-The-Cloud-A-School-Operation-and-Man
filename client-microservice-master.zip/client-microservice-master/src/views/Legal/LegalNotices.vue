<template>
  <div class="legal-notices">
    <h1>Legal notices</h1>
    <div>Last update: {{ legalnotices.updatedAt }}</div>
    <div>{{ legalnotices.content }}</div>
  </div>
</template>
<script>
export default {
    data() {
        return {
            legalnotices: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/legal-notices/latest`;

        this.axios.get(uri).then(response => {
            this.legalnotices = response.data;
        });
    },
};
</script>