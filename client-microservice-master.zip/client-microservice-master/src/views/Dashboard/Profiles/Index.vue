<template>
  <div>
    <h1>Profiles</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'profiles-create' }" class="btn btn-primary">Create Profile</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Account</th>
          <th>First name</th>
          <th>Last name</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(profile, index) in profiles" :key="profile._id">
          <td>{{ index+1 }}</td>
          <template v-for="user in users">
            <td :key="user._id" v-if="user._id === profile.user_id">{{ user.username }}</td>
          </template>
          <td>{{ profile.first_name }}</td>
          <td>{{ profile.last_name }}</td>
          <td>
            <router-link
              :to="{name: 'profiles-edit', params: { id: profile._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button class="btn btn-danger" @click.prevent="deleteProfile(profile._id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            profiles: [],
            users: [],
        };
    },
    created() {
        let uriProfiles = `http://localhost:4000/api/profiles`;

        this.axios.get(uriProfiles).then(response => {
            this.profiles = response.data;
        });

        let uriUsers = `http://localhost:4000/api/users`;

        this.axios.get(uriUsers).then(response => {
            this.users = response.data;
        });
    },
    methods: {
        deleteProfile(id) {
            let uri = `http://localhost:4000/api/profiles/${id}`;

            this.axios.delete(uri).then(response => {
                this.profiles.splice(this.profiles.indexOf(id), 1);
            });
        },
    },
};
</script>
