<template>
  <div>
    <h1>Edit Profile</h1>
    <form @submit.prevent="updateProfile">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Account:</label>

            <input type="text" class="form-control" v-model="user.username" readonly>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>First name:</label>
            <input type="text" class="form-control" v-model="profile.first_name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Last name:</label>
            <input type="text" class="form-control" v-model="profile.last_name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Phone:</label>
            <input type="number" class="form-control" v-model="profile.phone">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Mobile:</label>
            <input type="number" class="form-control" v-model="profile.mobile">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Email:</label>
            <input type="email" class="form-control" v-model="profile.email">
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            profile: {},
            user: {},
        };
    },
    created() {
        let uriProfile = `http://localhost:4000/api/profiles/${this.$route.params.id}`;
        this.axios.get(uriProfile).then(response => {
            this.profile = response.data;

            let uriUser = `http://localhost:4000/api/users/${this.profile.user_id}`;
            this.axios.get(uriUser).then(response => {
                this.user = response.data;
            });
        });
    },
    methods: {
        updateProfile() {
            let uri = `http://localhost:4000/api/profiles/${this.$route.params.id}`;
            this.axios.post(uri, this.profile).then(() => {
                this.$router.push({ name: 'profiles' });
            });
        },
    },
};
</script>
