<template>
  <div>
    <h1>Edit User</h1>
    <form @submit.prevent="updateUser">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Username:</label>
            <input type="text" class="form-control" v-model="user.username" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Password:</label>
            <input type="password" class="form-control" v-model="user.password" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Role:</label>
            <select v-model="user.role_id" :required="true">
              <option v-for="role in roles" v-bind:value="role._id" :key="role._id">{{ role.name }}</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>First name:</label>
            <input type="text" class="form-control" v-model="profile.first_name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Last name:</label>
            <input type="text" class="form-control" v-model="profile.last_name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Phone:</label>
            <input type="number" class="form-control" v-model="profile.phone">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Mobile:</label>
            <input type="number" class="form-control" v-model="profile.mobile">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Email:</label>
            <input type="email" class="form-control" v-model="profile.email">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>GUI's language:</label>
            <select v-model="setting.language">
              <option value="1">English</option>
              <option value="2">Français</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Be joined by :</label>
            <input type="checkbox" id="contact_chat" v-model="setting.contact_chat">
            <label for="chat">Chat</label>
            <input type="checkbox" id="contact_email" v-model="setting.contact_email">
            <label for="email">Email</label>
            <input type="checkbox" id="contact_phone" v-model="setting.contact_phone">
            <label for="phone">Phone</label>
            <input type="checkbox" id="contact_sms" v-model="setting.contact_sms">
            <label for="sms">SMS</label>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Received security notifications by :</label>
            <input
              type="checkbox"
              id="notification_dashboard"
              v-model="setting.notification_dashboard"
            >
            <label for="dashboard">Dashboard</label>
            <input type="checkbox" id="notification_email" v-model="setting.notification_email">
            <label for="email">Email</label>
            <input type="checkbox" id="notification_phone" v-model="setting.notification_phone">
            <label for="notification_push">Phone</label>
            <input type="checkbox" id="notification_push" v-model="setting.notification_push">
            <label for="push">Push</label>
            <input type="checkbox" id="notification_sms" v-model="setting.notification_sms">
            <label for="notification_sms">SMS</label>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            profiles: [],
            roles: [],
            settings: [],
            user: {},
            userProfile: {},
            userRole: {},
            userSetting: {},
        };
    },
    created() {
        let uriProfiles = `http://localhost:4000/api/profiles/`;

        this.axios.get(uriProfiles).then(response => {
            this.profiles = response.data;
        });

        let uriRoles = `http://localhost:4000/api/roles/`;

        this.axios.get(uriRoles).then(response => {
            this.roles = response.data;
        });

        let uriSettings = `http://localhost:4000/api/settings/`;

        this.axios.get(uriSettings).then(response => {
            this.settings = response.data;
        });

        let uriUser = `http://localhost:4000/api/users/${this.$route.params.id}`;
        this.axios.get(uriUser).then(response => {
            this.user = response.data;

            let uriRole = `http://localhost:4000/api/roles/${this.user.role_id}`;

            this.axios.get(uriRole).then(response => {
                this.userRole = response.data;
            });
        });
    },
    methods: {
        updateUser() {
            let uri = `http://localhost:4000/api/users/${this.$route.params.id}`;
            this.axios.post(uri, this.user).then(() => {
                this.$router.push({ name: 'users' });
            });
        },
    },
};
</script>
