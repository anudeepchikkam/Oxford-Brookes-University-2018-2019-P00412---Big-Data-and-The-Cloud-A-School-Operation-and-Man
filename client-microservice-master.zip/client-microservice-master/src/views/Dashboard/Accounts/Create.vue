<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create User</h1>
    <form @submit.prevent="createUser">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Username:</label>
            <input type="text" class="form-control" v-model="user.username" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Password:</label>
            <input type="password" class="form-control" v-model="user.password" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Role:</label>
            <select v-model="user.role_id" :required="true">
              <option disabled value>Choose</option>
              <option v-for="role in roles" v-bind:value="role._id" :key="role._id">{{ role.name }}</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>First name:</label>
            <input type="text" class="form-control" v-model="profile.first_name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Last name:</label>
            <input type="text" class="form-control" v-model="profile.last_name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Phone:</label>
            <input type="number" class="form-control" v-model="profile.phone">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Mobile:</label>
            <input type="number" class="form-control" v-model="profile.mobile">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Email:</label>
            <input type="email" class="form-control" v-model="profile.email">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>GUI's language:</label>
            <select v-model="setting.language">
              <option value="1">English</option>
              <option value="2">Français</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Be joined by :</label>
            <input type="checkbox" id="contact_chat" v-model="setting.contact_chat">
            <label for="chat">Chat</label>
            <input type="checkbox" id="contact_email" v-model="setting.contact_email">
            <label for="email">Email</label>
            <input type="checkbox" id="contact_phone" v-model="setting.contact_phone">
            <label for="phone">Phone</label>
            <input type="checkbox" id="contact_sms" v-model="setting.contact_sms">
            <label for="sms">SMS</label>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Received security notifications by :</label>
            <input
              type="checkbox"
              id="notification_dashboard"
              v-model="setting.notification_dashboard"
            >
            <label for="dashboard">Dashboard</label>
            <input type="checkbox" id="notification_email" v-model="setting.notification_email">
            <label for="email">Email</label>
            <input type="checkbox" id="notification_phone" v-model="setting.notification_phone">
            <label for="notification_push">Phone</label>
            <input type="checkbox" id="notification_push" v-model="setting.notification_push">
            <label for="push">Push</label>
            <input type="checkbox" id="notification_sms" v-model="setting.notification_sms">
            <label for="notification_sms">SMS</label>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
import mongoose from 'mongoose';

export default {
    data() {
        return {
            roles: [],
            profile: {},
            setting: {},
            user: {},
            userId: '',
            profileRes: {},
            settingRes: {},
            profile_id: '',
            setting_id: '',
        };
    },
    created() {
        let uriRoles = `http://localhost:4000/api/roles/`;

        this.axios.get(uriRoles).then(response => {
            this.roles = response.data;
        });
    },
    methods: {
        createUser() {
            let uriProfile = `http://localhost:4000/api/profiles`;
            let uriSetting = `http://localhost:4000/api/settings`;
            let uriUser = `http://localhost:4000/api/users`;
            this.axios
                .post(uriUser, this.user)
                .then(user => {
                    // id bug
                    //var userId = mongoose.Types.ObjectId(user.id.toString());
                    this.axios
                        .all([
                            this.axios.post(uriProfile, {
                                user_id: response.data.id,
                                first_name: this.profile.first_name,
                                last_name: this.profile.last_name,
                                phone: this.profile.phone,
                                mobile: this.profile.mobile,
                                email: this.profile.email,
                            }),
                            this.axios.post(uriSetting, {
                                user_id: response.data.id,
                                language_id: this.setting.language_id,
                                contact_chat: this.setting.contact_chat,
                                contact_email: this.setting.contact_email,
                                contact_phone: this.setting.contact_phone,
                                contact_sms: this.setting.contact_sms,
                                notification_dashboard: this.setting.notification_dashboard,
                                notification_email: this.setting.notification_email,
                                notification_phone: this.setting.notification_phone,
                                notification_push: this.setting.notification_pus,
                                notification_sms: this.setting.notification_sms,
                            }),
                        ])
                        .then(() => {
                            this.$router.push({ name: 'users' });
                        })
                        .catch(console.log);
                })
                .catch(console.log);
            /*
            this.axios
                .all([this.axios.post(uriProfile, this.profile), this.axios.post(uriSetting, this.setting)])
                .then(
                    this.axios.spread((profileRes, settingRes) => {
                       // id bug

                        var account = {
                            username: this.user.username,
                            password: this.user.password,
                            role_id: this.user.role_id,
                            profile_id: profileRes.data.id,
                            setting_id: settingRes.data.id,
                        };
                        console.log('R8');
                        console.log(account.username);
                        console.log('R9');
                        console.log(account.profile_id);
                        console.log(account.setting_id);
                        console.log(profileRes.data);
                        console.log(profileRes.data._id);
                        console.log(profileRes['data._id']);
                        this.axios
                            .post(uriUser, {
                                username: this.user.username,
                                password: this.user.password,
                                role_id: this.user.role_id,
                                profile_id: profileRes.data._id,
                                setting_id: settingRes.data._id,
                                //profile_id: profileRes.value.id,
                                //setting_id: settingRes.value.id,
                            })
                            .then(response => {
                                console.log(response);
                                console.log(response.data.id);
                                this.$router.push({ name: 'users' });
                            })
                            .catch(console.log);
                    }),
                )
                .catch(console.log);*/
        },
    },
};
</script>
