<template>
  <div class="container">
    <h1>Profile page</h1>

    <div class="card center" style="width: 38rem;">
      <img :src="profile.photo" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">{{ `${profile.firstName} ${profile.lastName}` }}</h5>
        <h6 class="card-subtitle mb-2 text-muted">Email: {{ profile.email }}</h6>
        <h6 class="card-subtitle mb-2 text-muted">Role: {{ profile.role }}</h6>
        <hr>
    <div class="text-dark text-left">
      <h1>Other Information</h1>
      <div v-if="showStudentInfo" class="student">
        <p class="card-text">Year Group: {{ profile.otherInfo.yearGroup }}</p>
        Hobbies:
        <ul class="list-unstyled pb-3">
          <li v-for="(hobby, index) in profile.otherInfo.hobbies" :key="index">{{ hobby }}</li>
        </ul>
        Modules:
        <ul class="list-unstyled pb-2">
          <li v-for="(module, indexs) in profile.otherInfo.modules" :key="indexs">{{ module }}</li>
        </ul>
        Favourite Sports:
        <ul class="list-unstyled pb-2">
          <li v-for="(sport, indexSport) in profile.otherInfo.favouriteSports" :key="indexSport">{{ sport }}</li>
        </ul>
      </div>
      <div v-if="showTeacherInfo" class="teacher">Teacher section</div>
      <div v-if="showSchoolManager" class="schoolManager">School Manager section</div>
      <div v-if="showEventOrganiser" class="eventOrganiser">event organiser section</div>
      <div v-if="showSystemOperator" class="systemOperator">system op section</div>
      <div v-if="showParent" class="parent">parent section</div>
    </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      showStudentInfo: false,
      showTeacherInfo: false,
      showSchoolManager: false,
      showEventOrganiser: false,
      showSystemOperator: false,
      showParent: false,

      profile: {
        firstName: 'Jeiman',
        lastName: 'Jeyas',
        email: '18027425@brookes.ac.uk',
        role: 'Student',
        photo: 'https://scontent-lht6-1.xx.fbcdn.net/v/t1.0-9/50601709_10161136540310316_2589377319663566848_o.jpg?_nc_cat=104&_nc_ht=scontent-lht6-1.xx&oh=ade271932ac2925747b8cd7f89c9d8ca&oe=5D6A3641',
        otherInfo: {}

      }
    };
  },
  created() {
    this.fetchProfile()

    let uri = `http://localhost:4000/api/profiles`;

    this.axios.get(uri).then(response => {
      this.profiles = response.data;
    });
  },
  methods: {
    fetchProfile () {
      // let uri = `http://localhost:4000/api/profiles/${id}`
      const profile = {
        role: 'student',
        otherInfo: {
          hobbies: ['Coding', 'Gaming', 'Netflixing', 'Gymming', 'Walking'],
          modules: ['Computer Science', 'English', 'IT', 'Phy. Ed.'],
          yearGroup: 'Year 12',
          favouriteSports: ['Gym', 'Football', 'American Football']

        }
      }

      this.profile.otherInfo = profile.otherInfo

      this.showStudentInfo = profile.role === 'student' ? true : false
      this.showTeacherInfo = profile.role === 'teacher' ? true : false
      this.showSchoolManager = profile.role === 'schoolManager' ? true : false
      this.showEventOrganiser = profile.role === 'eventOrganiser' ? true : false
      this.showSystemOperator = profile.role === 'systemOperator' ? true : false
      this.showParent = profile.role === 'parent' ? true : false

      if (profile.role === 'student') {
        this.showStudentInfo = true
      }
    },

    deleteProfile(id) {
      let uri = `http://localhost:4000/api/profiles/${id}`;

      this.axios.delete(uri).then(response => {
        this.profiles.splice(this.profiles.indexOf(id), 1);
      });
    }
  }
};
</script>
