<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create Terms of service</h1>
    <form @submit.prevent="createTermsOfService">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="termsofservice.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            termsofservice: {},
        };
    },
    methods: {
        createTermsOfService() {
            let uri = `http://localhost:4000/api/terms-of-services`;
            this.axios
                .post(uri, this.termsofservice)
                .then(() => {
                    this.$router.push({ name: 'terms-of-services' });
                })
                .catch(console.log);
        },
    },
};
</script>
