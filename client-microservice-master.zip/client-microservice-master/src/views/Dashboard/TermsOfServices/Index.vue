<template>
  <div>
    <h1>Terms of service</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link
          :to="{ name: 'terms-of-service-create' }"
          class="btn btn-primary"
        >Create Terms of service</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Content</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(termsofservice, index) in termsofservices" :key="termsofservice._id">
          <td>{{ index+1 }}</td>
          <td>{{ termsofservice.content }}</td>
          <td>
            <router-link
              :to="{name: 'terms-of-service-edit', params: { id: termsofservice._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button
              class="btn btn-danger"
              @click.prevent="deleteTermsOfService(termsofservice._id)"
            >Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            termsofservices: [],
        };
    },
    created() {
        let uri = `http://localhost:4000/api/terms-of-services`;

        this.axios.get(uri).then(response => {
            this.termsofservices = response.data;
        });
    },
    methods: {
        deleteTermsOfService(id) {
            let uri = `http://localhost:4000/api/terms-of-services/${id}`;

            this.axios.delete(uri).then(response => {
                this.termsofservices.splice(this.termsofservices.indexOf(id), 1);
            });
        },
    },
};
</script>
