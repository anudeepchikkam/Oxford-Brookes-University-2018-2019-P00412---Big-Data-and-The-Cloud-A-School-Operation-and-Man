<template>
  <div>
    <h1>Edit Terms of service</h1>
    <form @submit.prevent="updateTermsOfService">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="termsofservice.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            termsofservice: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/terms-of-services/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.termsofservice = response.data;
        });
    },
    methods: {
        updateTermsOfService() {
            let uri = `http://localhost:4000/api/terms-of-services/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'terms-of-services' });
            });
        },
    },
};
</script>
