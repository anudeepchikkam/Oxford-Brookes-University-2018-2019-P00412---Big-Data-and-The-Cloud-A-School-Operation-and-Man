<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create Event</h1>
    <form @submit.prevent="createEvent">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Event Id</label>
            <input type="text" class="form-control" v-model="event.eventId">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Event Name</label>
            <input type="text" class="form-control" v-model="event.eventName">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Event Description:</label>
            <textarea class="form-control" v-model="event.description" rows="6"></textarea>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Event DateTime:</label>
            <input type="datetime" class="form-control" v-model="event.dateTime">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Entry criteria:</label>
            <input type="text" class="form-control" v-model="event.entryCriteria">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Sponsorship Details:</label>
            <textarea class="form-control" v-model="event.sponsorshipDetails" rows="6"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            event: {},
        };
    },
    methods: {
        createEvent() {
            let uri = `http://localhost:4000/api/events`;
            this.axios
                .post(uri, this.event)
                .then(() => {
                    this.$router.push({ name: 'events' });
                })
                .catch((error) => {
                  console.log('Error creating event', error);
                });
        },
    },
    
};
</script>
