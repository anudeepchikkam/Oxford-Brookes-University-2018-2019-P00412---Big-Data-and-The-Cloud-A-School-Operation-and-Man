<template>
  <div>
    <h1>Edit Event</h1>
    <form @submit.prevent="updateEvent">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Event Id</label>
            <input type="text" class="form-control" v-model="event.eventId">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Event Name</label>
            <input type="text" class="form-control" v-model="event.eventName">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Event Description:</label>
            <textarea class="form-control" v-model="event.description" rows="6"></textarea>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Event Date and Time:</label>
            <input type="datetime" class="form-control" v-model="event.dateTime">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Entry criteria:</label>
            <input type="text" class="form-control" v-model="event.entryCriteria">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Sponsorship Details:</label>
            <textarea class="form-control" v-model="event.sponsorshipDetails" rows="6"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            event: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/events/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.event = response.data;
        });
    },
    methods: {
        updateEvent() {
            let uri = `http://localhost:4000/api/events/${this.$route.params.id}`;
            this.axios.post(uri, this.event).then(() => {
                this.$router.push({ name: 'events' });
            });
        },
    },
};
</script>
