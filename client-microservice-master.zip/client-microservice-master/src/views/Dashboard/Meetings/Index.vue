<template>
  <div>
    <h1>Meetings</h1>
    <div class="row">
      <div class="col-md-10">
        <b-button v-b-modal.modal-1>Invitations</b-button>
        <b-modal id="modal-1" title="Invitations">
          <div class="row" v-for="(invitation, index) in invitations" :key="index">
            <div class="col-md-6">
              <b-card>
                <b-card-text>Status: {{ invitation.status }}</b-card-text>
                <b-card-text v-for="(attendeeDetails, atIndex) in invitation.attendeeDetails" :key="atIndex">{{ attendeeDetails.first_name }}</b-card-text>
              </b-card>
            </div>
            <div class="col-md-6">
              <b-button>Accept</b-button>
              <b-button class="btn btn-danger">Decline</b-button>
            </div>
          </div>
        </b-modal>
      </div>
      <div class="col-md-2">
        <router-link :to="{ name: 'meetings-create' }" class="btn btn-primary">Create Meeting</router-link>
      </div>
    </div>
    <br>
<b-card class="my-3" v-for="meeting in orderMeetings" :key="meeting._id">
    <b-card-text class="bg-info text-white rounded py-1 px-2" v-if="meeting.inviteOnly === 'Yes'">Invite Only</b-card-text>
    <b-card-title>Title: {{ meeting.title }}</b-card-title>
    <b-card-title>Duration:</b-card-title>
    <b-card-text>{{ meeting.startDate }} &bull; {{ meeting.endDate }}</b-card-text>
    <b-card-title>Location:</b-card-title>
    <b-card-text>{{ meeting.location }}</b-card-text>
    <b-card-title>Attendees:</b-card-title>
    <b-card-text><p v-for="(attendee, index) in meeting.attendees" :key="index">{{ `${attendee.first_name} ${attendee.last_name}` }}</p></b-card-text>
    <b-card-title>Description: </b-card-title>
    <b-card-text><span style="white-space: pre-wrap;">{{ meeting.description }}</span></b-card-text>
    <b-card-title>Invite Only?:</b-card-title>
    <b-card-text class="d-inline-block mr-3">{{ meeting.inviteOnly }}</b-card-text>
    <a v-if="meeting.inviteOnly === 'Yes'" class="d-inline" href="#">Request invite</a>
    <b-card-title>Contact Organiser:</b-card-title>
    <b-card-text><b>Name:</b> {{ `${meeting.organiserProfile.first_name} ${meeting.organiserProfile.last_name}` }}</b-card-text>
    <b-card-text><b>Email:</b> {{ meeting.organiserProfile.email }}</b-card-text>
    <b-card-text><b>Phone:</b> {{ meeting.organiserProfile.phone }}</b-card-text>
    <router-link :to="{name: 'meetings-edit', params: { id: meeting._id }}" class="btn btn-primary">Edit</router-link>
    <b-link class="btn btn-danger mx-3" @click.prevent="deleteMeeting(meeting._id)">Delete</b-link>
  </b-card>
  </div>
</template>

<script>
// Import library
import _ from 'lodash';

export default {
  data() {
    return {
      meetings: [],
      attendees: [],
      invitations: [],
      user: {
        type: 'student',
      }
    };
  },
  created() {
    const meetingUrl = 'http://localhost:4000/api/meetings';
    // const profileUrl = 'http://localhost:4000/api/profiles/';
    const invitationUrl = 'http://localhost:4000/api/invitations';
    this.axios.get(meetingUrl).then(response => {
      this.meetings = response.data;
    })
    .catch((error) => {
      console.log('Error fetching meetings', error)
    });

    this.axios.get(invitationUrl).then(response => {
      this.invitations = response.data;
    })
    .catch((error) => {
      console.log('Error fetching invitations', error)
    });
  },
  computed: {
    orderMeetings: function () {
      return _.orderBy(this.meetings, 'createdAt', 'desc')
    }
  },
  methods: {
    deleteMeeting(id) {
      const uri = `http://localhost:4000/api/meetings/${id}`;
      
      this.axios.delete(uri).then(response => {
        this.meetings.splice(this.meetings.indexOf(id), 1);
      });
    },
  } 
};
</script>
