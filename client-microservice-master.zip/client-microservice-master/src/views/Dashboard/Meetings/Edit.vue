<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Update Meeting</h1>
    <form @submit.prevent="updateMeeting">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Title:</label>
            <input type="text" class="form-control" v-model="meeting.title">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Start Date:</label>
            <datetime type="datetime" title="Pick a start date" v-model="meeting.startDate" input-class="form-control" placeholder="Pick a start date"></datetime>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>End Date:</label>
            <datetime type="datetime" title="Pick an end date" v-model="meeting.endDate" input-class="form-control" placeholder="Pick an end date"></datetime>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Location:</label>
            <input type="text" class="form-control" v-model="meeting.location">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Attendees:</label><br>
            <select v-model="meeting.attendees" :required="true" multiple>
              <option v-for="profile in profiles" v-bind:value="profile._id" :key="profile._id">{{ `${profile.first_name} ${profile.last_name}` }}</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Description:</label>
            <textarea rows="4" cols="50" class="form-control" v-model="meeting.description"></textarea>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Type of Meeting:</label>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="public" v-model="meeting.typeOfMeeting" checked>
              <label class="form-check-label" for="exampleRadios1">
                Public meeting
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="private" v-model="meeting.typeOfMeeting">
              <label class="form-check-label" for="exampleRadios2">
                Private meeting
              </label>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Invite Only?:</label>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="true" v-model="meeting.inviteOnly" checked>
              <label class="form-check-label" for="exampleRadios3">
                Yes
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios4" value="false" v-model="meeting.inviteOnly">
              <label class="form-check-label" for="exampleRadios4">
                No
              </label>
            </div>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      showError: false,
      meeting: {
        attendees: []
      },
      profiles: [],
    };
  },
  created() {
    const profilesUrl = 'http://localhost:4000/api/profiles/';
    const meetingsUrl = `http://localhost:4000/api/meetings/${this.$route.params.id}`;

    this.axios.get(meetingsUrl).then(response => {
      this.meeting = response.data;
    }).catch((error) => {
      console.log('Error fetching meetings', error);
    });

    this.axios.get(profilesUrl).then(response => {
      this.profiles = response.data;
      console.log(this.profiles);
    }).catch((error) => {
      console.log('Error fetching profiles', error);
    });
  },
  methods: {
    updateMeeting() {
      const uri = `http://localhost:4000/api/meetings/${this.$route.params.id}`;
      this.meeting.organiserId = '5ccfd5adbe3363f4b6733648'; // This value will be dynamic according to profile ID from state management

      this.axios.post(uri, this.meeting).then(() => {
        this.$router.push({ name: "meetings" });
      }).catch((error) => {
        this.showError = true
        console.log('Error updating meeting', error)
      });
    }
  }
};
</script>
