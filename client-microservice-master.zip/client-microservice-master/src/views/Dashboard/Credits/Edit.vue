<template>
  <div>
    <h1>Edit Credits</h1>
    <form @submit.prevent="updateCredits">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="credits.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            credits: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/credits/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.credits = response.data;
        });
    },
    methods: {
        updateCredits() {
            let uri = `http://localhost:4000/api/credits/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'credits' });
            });
        },
    },
};
</script>
