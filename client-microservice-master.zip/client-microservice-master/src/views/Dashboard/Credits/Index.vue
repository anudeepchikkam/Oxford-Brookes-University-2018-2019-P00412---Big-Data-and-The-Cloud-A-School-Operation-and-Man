<template>
  <div>
    <h1>Credits</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'credits-create' }" class="btn btn-primary">Create Credits</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Content</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(credits, index) in creditss" :key="credits._id">
          <td>{{ index+1 }}</td>
          <td>{{ credits.content }}</td>
          <td>
            <router-link
              :to="{name: 'credits-edit', params: { id: credits._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button class="btn btn-danger" @click.prevent="deleteCredits(credits._id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            creditss: [],
        };
    },
    created() {
        let uri = `http://localhost:4000/api/credits`;

        this.axios.get(uri).then(response => {
            this.creditss = response.data;
        });
    },
    methods: {
        deleteCredits(id) {
            let uri = `http://localhost:4000/api/credits/${id}`;

            this.axios.delete(uri).then(response => {
                this.creditss.splice(this.creditss.indexOf(id), 1);
            });
        },
    },
};
</script>
