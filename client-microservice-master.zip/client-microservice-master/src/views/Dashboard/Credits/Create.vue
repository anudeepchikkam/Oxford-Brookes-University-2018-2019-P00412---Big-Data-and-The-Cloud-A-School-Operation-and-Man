<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create Credits</h1>
    <form @submit.prevent="createCredits">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="credits.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            credits: {},
        };
    },
    methods: {
        createCredits() {
            let uri = `http://localhost:4000/api/credits`;
            this.axios
                .post(uri, this.credits)
                .then(() => {
                    this.$router.push({ name: 'credits' });
                })
                .catch(console.log);
        },
    },
};
</script>
