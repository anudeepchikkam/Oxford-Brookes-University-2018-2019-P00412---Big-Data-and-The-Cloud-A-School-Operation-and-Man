<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create About</h1>
    <form @submit.prevent="createAbout">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <editor
              api-key="gksbabvu97buoklkkcyslloq99k95opx1dh25sjr1um0qezf"
              :init="{selector: 'textarea',
   toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter insertfile pageembed permanentpen',
   toolbar_drawer: 'sliding',
   tinycomments_mode: 'embedded'}"
              v-model="about.content"
            />
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            about: {},
        };
    },
    methods: {
        createAbout() {
            let uri = `http://localhost:4000/api/abouts`;
            this.axios
                .post(uri, this.about)
                .then(() => {
                    this.$router.push({ name: 'abouts' });
                })
                .catch(console.log);
        },
    },
};
</script>
