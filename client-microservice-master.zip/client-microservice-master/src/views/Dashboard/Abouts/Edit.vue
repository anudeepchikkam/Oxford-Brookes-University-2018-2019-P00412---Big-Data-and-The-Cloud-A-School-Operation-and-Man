<template>
  <div>
    <h1>Edit About</h1>
    <form @submit.prevent="updateAbout">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="about.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            about: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/abouts/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.about = response.data;
        });
    },
    methods: {
        updateAbout() {
            let uri = `http://localhost:4000/api/abouts/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'abouts' });
            });
        },
    },
};
</script>
