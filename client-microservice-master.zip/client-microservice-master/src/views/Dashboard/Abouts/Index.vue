<template>
  <div>
    <h1>Abouts</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'abouts-create' }" class="btn btn-primary">Create About</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Content</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(about, index) in abouts" :key="about._id">
          <td>{{ index+1 }}</td>
          <td>{{ about.content }}</td>
          <td>
            <router-link
              :to="{name: 'abouts-edit', params: { id: about._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button class="btn btn-danger" @click.prevent="deleteAbout(about._id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            abouts: [],
        };
    },
    created() {
        let uri = `http://localhost:4000/api/abouts`;

        this.axios.get(uri).then(response => {
            this.abouts = response.data;
        });
    },
    methods: {
        deleteAbout(id) {
            let uri = `http://localhost:4000/api/abouts/${id}`;

            this.axios.delete(uri).then(response => {
                this.abouts.splice(this.abouts.indexOf(id), 1);
            });
        },
    },
};
</script>
