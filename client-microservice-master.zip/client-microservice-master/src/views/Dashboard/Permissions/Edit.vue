<template>
  <div>
    <h1>Edit Permission</h1>
    <form @submit.prevent="updatePermission">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Slug</label>
            <input type="text" name="slug" class="form-control" v-model="permission.slug">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" class="form-control" v-model="permission.name">
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            permission: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/permissions/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.permission = response.data;
        });
    },
    methods: {
        updatePermission() {
            let uri = `http://localhost:4000/api/permissions/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'permissions' });
            });
        },
    },
};
</script>
