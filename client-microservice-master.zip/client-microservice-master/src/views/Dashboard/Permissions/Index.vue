<template>
  <div>
    <h1>Permissions</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'permissions-create' }" class="btn btn-primary">Create Permission</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Slug</th>
          <th>Name</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(permission, index) in permissions" :key="permission._id">
          <td>{{ index+1 }}</td>
          <td>{{ permission.slug }}</td>
          <td>{{ permission.name }}</td>
          <td>
            <router-link
              :to="{name: 'permissions-edit', params: { id: permission._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button class="btn btn-danger" @click.prevent="deletePermission(permission._id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            permissions: [],
        };
    },
    created() {
        let uri = `http://localhost:4000/api/permissions`;

        this.axios.get(uri).then(response => {
            this.permissions = response.data;
        });
    },
    methods: {
        deletePermission(id) {
            let uri = `http://localhost:4000/api/permissions/${id}`;

            this.axios.delete(uri).then(response => {
                this.permissions.splice(this.permissions.indexOf(id), 1);
            });
        },
    },
};
</script>
