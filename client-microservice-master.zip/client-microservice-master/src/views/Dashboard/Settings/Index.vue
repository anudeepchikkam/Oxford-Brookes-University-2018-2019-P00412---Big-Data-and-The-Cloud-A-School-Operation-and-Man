<template>
  <div>
    <h1>Settings</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'settings-create' }" class="btn btn-primary">Create Setting</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Account</th>
          <th>First name</th>
          <th>Last name</th>
          <th>Language</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(setting, index) in settings" :key="setting._id">
          <td>{{ index+1 }}</td>
          <template v-for="user in users">
            <td :key="user._id" v-if="user._id === setting.user_id">{{ user.username }}</td>
          </template>
          <td>{{ setting.first_name }}</td>
          <td>{{ setting.last_name }}</td>
          <td>{{ setting.language_id }}</td>
          <td>
            <router-link
              :to="{name: 'settings-edit', params: { id: setting._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button class="btn btn-danger" @click.prevent="deleteSetting(setting._id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            profiles: [],
            settings: [],
            users: [],
        };
    },
    created() {
        let uriProfiles = `http://localhost:4000/api/profiles`;

        this.axios.get(uriProfiles).then(response => {
            this.profiles = response.data;
        });

        let uriSettings = `http://localhost:4000/api/settings`;

        this.axios.get(uriSettings).then(response => {
            this.settings = response.data;
        });

        let uriUsers = `http://localhost:4000/api/users`;

        this.axios.get(uriUsers).then(response => {
            this.users = response.data;
        });
    },
    methods: {
        deleteSetting(id) {
            let uri = `http://localhost:4000/api/settings/${id}`;

            this.axios.delete(uri).then(response => {
                this.settings.splice(this.settings.indexOf(id), 1);
            });
        },
    },
};
</script>
