<template>
  <div>
    <h1>Edit Setting</h1>
    <form @submit.prevent="updateSetting">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Account:</label>

            <input type="text" class="form-control" v-model="setting.user_id" readonly>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>GUI's language:</label>
            <select v-model="setting.language_id">
              <option value="1">English</option>
              <option value="2">Français</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Be joined by :</label>
            <input type="checkbox" id="contact_chat" v-model="setting.contact_chat">
            <label for="chat">Chat</label>
            <input type="checkbox" id="contact_email" v-model="setting.contact_email">
            <label for="email">Email</label>
            <input type="checkbox" id="contact_phone" v-model="setting.contact_phone">
            <label for="phone">Phone</label>
            <input type="checkbox" id="contact_sms" v-model="setting.contact_sms">
            <label for="sms">SMS</label>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Received security notifications by :</label>
            <input
              type="checkbox"
              id="notification_dashboard"
              v-model="setting.notification_dashboard"
            >
            <label for="dashboard">Dashboard</label>
            <input type="checkbox" id="notification_email" v-model="setting.notification_email">
            <label for="email">Email</label>
            <input type="checkbox" id="notification_phone" v-model="setting.notification_phone">
            <label for="notification_push">Phone</label>
            <input type="checkbox" id="notification_push" v-model="setting.notification_push">
            <label for="push">Push</label>
            <input type="checkbox" id="notification_sms" v-model="setting.notification_sms">
            <label for="notification_sms">SMS</label>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            setting: {},
            user: {},
        };
    },
    created() {
        let uriSetting = `http://localhost:4000/api/settings/${this.$route.params.id}`;
        this.axios.get(uriSetting).then(response => {
            this.setting = response.data;

            let uriUser = `http://localhost:4000/api/users/${this.setting.user_id}`;
            this.axios.get(uriUser).then(response => {
                this.user = response.data;
            });
        });
    },
    methods: {
        updateSetting() {
            let uri = `http://localhost:4000/api/settings/${this.$route.params.id}`;
            this.axios.post(uri, this.setting).then(() => {
                this.$router.push({ name: 'settings' });
            });
        },
    },
};
</script>
