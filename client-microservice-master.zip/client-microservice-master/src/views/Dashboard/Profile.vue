<template>
  <div>
    <h1>Profile</h1>
    <div class="card center" style="width: 38rem;">
      <img :src="profile.photo" class="card-img-top" alt="...">
      <div class="card-body">
        <form @submit.prevent="updateProfile">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>First name:</label>
                <input type="text" class="form-control" v-model="profile.first_name">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Last name:</label>
                <input type="text" class="form-control" v-model="profile.last_name">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Role:</label>
                <input type="text" class="form-control" v-model="profile.role" readonly>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Phone:</label>
                <input type="number" class="form-control" v-model="profile.phone">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Mobile:</label>
                <input type="number" class="form-control" v-model="profile.mobile">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>E-mail:</label>
                <input type="email" class="form-control" v-model="profile.email">
              </div>
            </div>
          </div>
          <br>
          <div class="form-group">
            <button class="btn btn-primary">Update</button>
          </div>
        </form>
        <!--
        <h5 class="card-title">{{ `${profile.first_name} ${profile.last_name}` }}</h5>
        <h6 class="card-subtitle mb-2 text-muted">Email: {{ profile.email }}</h6>
        <h6 class="card-subtitle mb-2 text-muted">Role: {{ profile.role }}</h6>
        -->
        <hr>
        <div class="text-dark text-left">
          <h1>Other Information</h1>
          <div v-if="showStudentInfo" class="student">
            <p class="card-text">Year Group: {{ profile.otherInfo.yearGroup }}</p>Hobbies:
            <ul class="list-unstyled pb-3">
              <li v-for="(hobby, index) in profile.otherInfo.hobbies" :key="index">{{ hobby }}</li>
            </ul>Modules:
            <ul class="list-unstyled pb-2">
              <li v-for="(module, indexs) in profile.otherInfo.modules" :key="indexs">{{ module }}</li>
            </ul>Favourite Sports:
            <ul class="list-unstyled pb-2">
              <li
                v-for="(sport, indexSport) in profile.otherInfo.favouriteSports"
                :key="indexSport"
              >{{ sport }}</li>
            </ul>
          </div>
          <div v-if="showTeacherInfo" class="teacher">Teacher section</div>
          <div v-if="showSchoolManager" class="schoolManager">School Manager section</div>
          <div v-if="showEventOrganiser" class="eventOrganiser">event organiser section</div>
          <div v-if="showSystemOperator" class="systemOperator">system op section</div>
          <div v-if="showParent" class="parent">parent section</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
    data() {
        return {
            showStudentInfo: false,
            showTeacherInfo: false,
            showSchoolManager: false,
            showEventOrganiser: false,
            showSystemOperator: false,
            showParent: false,

            profile: {
                first_name: 'Jeiman',
                last_name: 'Jeyas',
                email: '18027425@brookes.ac.uk',
                role: 'Student',
                photo:
                    'https://scontent-lht6-1.xx.fbcdn.net/v/t1.0-9/50601709_10161136540310316_2589377319663566848_o.jpg?_nc_cat=104&_nc_ht=scontent-lht6-1.xx&oh=ade271932ac2925747b8cd7f89c9d8ca&oe=5D6A3641',
                otherInfo: {},
            },
        };
    },
    created() {
        this.fetchProfile();

        let uri = `http://localhost:4000/api/profiles/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.profile = response.data;
        });
    },
    methods: {
        fetchProfile() {
            // let uri = `http://localhost:4000/api/profiles/${id}`
            const profile = {
                role: 'student',
                otherInfo: {
                    hobbies: ['Coding', 'Gaming', 'Netflixing', 'Gymming', 'Walking'],
                    modules: ['Computer Science', 'English', 'IT', 'Phy. Ed.'],
                    yearGroup: 'Year 12',
                    favouriteSports: ['Gym', 'Football', 'American Football'],
                },
            };

            this.profile.otherInfo = profile.otherInfo;

            this.showStudentInfo = profile.role === 'student' ? true : false;
            this.showTeacherInfo = profile.role === 'teacher' ? true : false;
            this.showSchoolManager = profile.role === 'schoolManager' ? true : false;
            this.showEventOrganiser = profile.role === 'eventOrganiser' ? true : false;
            this.showSystemOperator = profile.role === 'systemOperator' ? true : false;
            this.showParent = profile.role === 'parent' ? true : false;

            if (profile.role === 'student') {
                this.showStudentInfo = true;
            }
        },
        updateProfile() {
            let uri = `http://localhost:4000/api/profiles/${this.$route.params.id}`;
            this.axios.post(uri, this.profile).then(() => {
                this.$router.push({ name: 'profile' });
            });
        },
    },
};
</script>
