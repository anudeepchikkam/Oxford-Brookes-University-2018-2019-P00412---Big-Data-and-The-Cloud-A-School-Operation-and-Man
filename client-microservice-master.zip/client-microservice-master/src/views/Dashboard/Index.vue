<template>
<div class="container-fluid">
  <h1>Latest News</h1>

  <b-card title="Card title" sub-title="Card subtitle">
    <b-card-title>New Event: Harry Potter Reunion Party</b-card-title>
    <b-card-text>
      Wingardium Leviosaaaaaaaaaa!!! Yes, you heard me right.
    </b-card-text>
    <b-link href="#" class="card-link">View Event</b-link>
  </b-card>

  <b-card img-src="https://placekitten.com/300/300" img-alt="Card image" img-right>
    <b-card-title>New Event: Rescue The Kittens</b-card-title>
    <span class="card-span">Datetime: 10 June 2018</span>
    <b-card-text>We are a group of volunteers who do what we can to help cats in need in south and west Oxfordshire, and Vale of White Horse. We cover these postcodes: OX1, 2, 3, 4, 10, 11, 12, 13, 14, 18, 20, 28, 29, 33, 44, 49 and SN7. However, if you are outside the area and aren't sure who to contact, let us know, and we will put you in touch with the appropriate branch of CP.</b-card-text>
    <b-link href="#" class="card-link">View Event</b-link>
  </b-card>
</div>
</template>

<script>

export default {
  name: "Dashboard",
  components: {
  }
};
</script>

<style lang="scss" scoped>
.card, .card-text {
  margin: 30px 0px;
}
</style>