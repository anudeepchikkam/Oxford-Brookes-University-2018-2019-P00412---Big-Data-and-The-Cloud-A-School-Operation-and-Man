<template>
  <div>
    <h1>Events</h1>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Event ID </th>
          <th>Event name </th>
          <th>Description</th>
          <th>Entry Criteria</th> 
          <th>Sponsorship Details</th> 
          <th>Date and Time</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(event, index) in events" :key="event._id">
          <td>{{ index+1 }}</td>
          <td>{{ event.eventId}}</td>
          <td>{{ event.eventName }}</td>
          <td>{{ event.description }}</td>
          <td>{{ event.entryCriteria }}</td>
          <td>{{ event.sponsorshipDetails }}</td>
          <td>{{ event.dateTime }}</td>
          <td>Active </td>
          <td>
            <button class="btn btn-primary" @click.prevent="register(event._id)">Apply</button>
          </td>
        </tr>
        <tr>
          <td>1</td>
          <td>Ukasoams18029</td>
          <td>Science Fair</td>
          <td>Science projects prototype to protect environment</td>
          <td>7 to 12 grade students</td>
          <td>uk department</td>
          <td>08/05/2019 
            10:00
          </td>
          <td>Active </td>
          <td>            
            <button class="btn btn-primary" @click.prevent="register(1)">Apply</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      events: []
    };
  },
  created() {
    let uri = `http://localhost:4000/api/events`;

    this.axios.get(uri).then(response => {
      this.events = response.data;
    });
  },
  methods: {
    register(id) {
      let uri = `http://localhost:4000/api/events/${id}`;
    }
  }
};
</script>
