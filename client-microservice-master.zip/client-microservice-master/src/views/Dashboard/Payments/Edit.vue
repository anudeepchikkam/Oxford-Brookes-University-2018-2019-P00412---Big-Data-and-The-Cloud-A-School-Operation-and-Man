<template>
  <div>
    <h1>Edit Payment</h1>
    <form @submit.prevent="updatePayment">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Date</label>
            <input type="date" class="form-control" v-model="payment.date">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Operation</label>
            <input type="text" class="form-control" v-model="payment.operation">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Status</label>
            <input type="checkbox" class="form-control" v-model="payment.status">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Debit</label>
            <input type="number" class="form-control" v-model="payment.debit">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Credit</label>
            <input type="number" class="form-control" v-model="payment.credit">
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            payment: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/payments/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.payment = response.data;
        });
    },
    methods: {
        updatePayment() {
            let uri = `http://localhost:4000/api/payments/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'payments' });
            });
        },
    },
};
</script>
