<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create Payment</h1>
    <form @submit.prevent="createPayment">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Date</label>
            <input type="date" class="form-control" v-model="payment.date" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Operation</label>
            <input type="text" class="form-control" v-model="payment.operation" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Status</label>
            <input type="checkbox" class="form-control" v-model="payment.status" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Debit</label>
            <input type="number" class="form-control" v-model="payment.debit">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Credit</label>
            <input type="number" class="form-control" v-model="payment.credit">
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>c
    </form>
  </div>
</template>

<script>
import mongoose from 'mongoose';

export default {
    data() {
        return {
            payments: [],
            user: {},
        };
    },
    created() {
        let uriPayments = `http://localhost:4000/api/payments/`;

        this.axios.get(uriPayments).then(response => {
            this.payments = response.data;
        });
    },
    methods: {
        createPayment() {
            let uri = `http://localhost:4000/api/payments`;

            this.axios
                .post(uri, this.payment)
                .then(() => {
                    this.$router.push({ name: 'payments' });
                })
                .catch(console.log);
        },
    },
};
</script>