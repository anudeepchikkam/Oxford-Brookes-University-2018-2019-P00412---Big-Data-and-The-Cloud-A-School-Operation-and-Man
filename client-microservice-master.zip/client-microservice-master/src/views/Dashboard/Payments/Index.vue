<template>
  <div>
    <h1>Payments</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'payments-create' }" class="btn btn-primary">Create Payments</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Date</th>
          <th>Operation</th>
          <th>Status</th>
          <th>Debit</th>
          <th>Credit</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(payment, index) in payments" :key="payment._id">
          <td>{{ index+1 }}</td>
          <td>{{ payment.date }}</td>
          <td>{{ payment.operation }}</td>
          <td>{{ payment.status }}</td>
          <td>{{ payment.debit }}</td>
          <td>{{ payment.credit }}</td>
          <td>
            <router-link
              :to="{name: 'payments-edit', params: { id: payments._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button class="btn btn-danger" @click.prevent="deletePayment(payments._id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            payments: [],
            profiles: [],
            users: [],
        };
    },
    created() {
        let uriPayments = `http://localhost:4000/api/payments`;

        this.axios.get(uriPayments).then(response => {
            this.payments = response.data;
        });

        let uriProfiles = `http://localhost:4000/api/profiles`;

        this.axios.get(uriProfiles).then(response => {
            this.profiles = response.data;
        });

        let uriUsers = `http://localhost:4000/api/users`;

        this.axios.get(uriUsers).then(response => {
            this.users = response.data;
        });
    },
    methods: {
        deletePayment(id) {
            let uri = `http://localhost:4000/api/payments/${id}`;

            this.axios.delete(uri).then(response => {
                this.users.splice(this.users.indexOf(id), 1);
            });
        },
    },
};
</script>