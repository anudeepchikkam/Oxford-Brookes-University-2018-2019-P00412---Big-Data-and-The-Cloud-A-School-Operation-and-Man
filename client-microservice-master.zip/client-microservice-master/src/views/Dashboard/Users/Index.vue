<template>
  <div>
    <h1>Users</h1>
    <div class="row">
      <div class="col-md-6"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'accounts-create' }" class="btn btn-primary">Create Account</router-link>
      </div>
      <div class="col-md-4">
        <router-link
          :to="{ name: 'users-create' }"
          class="btn btn-primary"
        >Create User credentials only</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Username</th>
          <th>First name</th>
          <th>Last name</th>
          <th>Role</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(user, index) in users" :key="user._id">
          <td>{{ index+1 }}</td>
          <td>{{ user.username }}</td>
          <template v-for="profile in profiles">
            <td :key="profile._id" v-if="profile.user_id === user._id">{{ profile.first_name }}</td>
            <td :key="profile._id" v-if="profile.user_id === user._id">{{ profile.last_name }}</td>
          </template>
          <template v-for="role in roles">
            <td :key="role._id" v-if="role._id === user.role_id">{{ role.name }}</td>
          </template>
          <td>
            <router-link
              :to="{name: 'users-edit', params: { id: user._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button class="btn btn-danger" @click.prevent="deleteUser(user._id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            profiles: [],
            roles: [],
            users: [],
        };
    },
    created() {
        let uriProfiles = `http://localhost:4000/api/profiles`;

        this.axios.get(uriProfiles).then(response => {
            this.profiles = response.data;
        });

        let uriRoles = `http://localhost:4000/api/roles/`;

        this.axios.get(uriRoles).then(response => {
            this.roles = response.data;
        });

        let uriUsers = `http://localhost:4000/api/users`;

        this.axios.get(uriUsers).then(response => {
            this.users = response.data;
        });
    },
    methods: {
        deleteUser(id) {
            let uri = `http://localhost:4000/api/users/${id}`;

            this.axios.delete(uri).then(response => {
                this.users.splice(this.users.indexOf(id), 1);
            });
        },
    },
};
</script>
