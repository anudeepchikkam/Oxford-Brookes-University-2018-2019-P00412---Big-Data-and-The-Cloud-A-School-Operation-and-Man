<template>
  <div>
    <h1>Edit User</h1>
    <form @submit.prevent="updateUser">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Username:</label>
            <input type="text" class="form-control" v-model="user.username" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Password:</label>
            <input type="password" class="form-control" v-model="user.password" :required="true">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Role:</label>
            <select v-model="user.role_id" :required="true">
              <option v-for="role in roles" v-bind:value="role._id" :key="role._id">{{ role.name }}</option>
            </select>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            roles: [],
            user: {},
            userRole: {},
        };
    },
    created() {
        let uriRoles = `http://localhost:4000/api/roles/`;

        this.axios.get(uriRoles).then(response => {
            this.roles = response.data;
        });

        let uriUser = `http://localhost:4000/api/users/${this.$route.params.id}`;
        this.axios.get(uriUser).then(response => {
            this.user = response.data;

            let uriRole = `http://localhost:4000/api/roles/${this.user.role_id}`;

            this.axios.get(uriRole).then(response => {
                this.userRole = response.data;
            });
        });
    },
    methods: {
        updateUser() {
            let uri = `http://localhost:4000/api/users/${this.$route.params.id}`;
            this.axios.post(uri, this.user).then(() => {
                this.$router.push({ name: 'users' });
            });
        },
    },
};
</script>
