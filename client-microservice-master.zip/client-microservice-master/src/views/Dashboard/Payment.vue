<template>
  <div>
    <h1>Payments</h1>
    <div class="row">
      <div class="col-md-8"></div>
      <div class="col-md-4">
        <a
          href="https://secure.payplug.com/p/test/Duy3"
          target="_blank"
          base_url="https://secure.payplug.com"
          class="btn btn-primary"
        >Proceed to payment</a>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Date</th>
          <th>Operation</th>
          <th>Status</th>
          <th>Debit</th>
          <th>Credit</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(payment, index) in payments" :key="payment._id">
          <td>{{ index+1 }}</td>
          <td>{{ payment.date }}</td>
          <td>{{ payment.operation }}</td>
          <td>{{ payment.status }}</td>
          <td>{{ payment.debit }}</td>
          <td>{{ payment.credit }}</td>
        </tr>
       <td>02/02/2019</td>
          <td>Registration for event</td>
          <td>Paid</td>
          <td>40£</td>
          <td>40£</td>
          </td>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            payments: [],
            users: [],
        };
    },
    created() {
        let uriPayments = `http://localhost:4000/api/payments`;

        this.axios.get(uriPayments).then(response => {
            this.payments = response.data;
        });

        let uriUsers = `http://localhost:4000/api/users`;

        this.axios.get(uriUsers).then(response => {
            this.users = response.data;
        });
    },
};
</script>
