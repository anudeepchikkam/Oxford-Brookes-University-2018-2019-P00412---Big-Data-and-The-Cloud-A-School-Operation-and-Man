<template>
  <div>
    <h1>Edit Role</h1>
    <form @submit.prevent="updateRole">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Slug</label>
            <input type="text" class="form-control" v-model="role.slug">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Name</label>
            <input type="text" class="form-control" v-model="role.name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Permissions</label>
            <select v-model="role.permissions" multiple>
              <option
                v-for="(permission, index) in permissions"
                v-bind:value="permission._id"
                :key="permission._id"
              >{{ index+1 }} - {{ permission.name }}</option>
            </select>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            permissions: [],
            role: {},
        };
    },
    created() {
        let uriPermissions = `http://localhost:4000/api/permissions`;

        this.axios.get(uriPermissions).then(response => {
            this.permissions = response.data;
        });

        let uriRole = `http://localhost:4000/api/roles/${this.$route.params.id}`;
        this.axios.get(uriRole).then(response => {
            this.role = response.data;
        });
    },
    methods: {
        updateRole() {
            let uri = `http://localhost:4000/api/roles/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'roles' });
            });
        },
    },
};
</script>
