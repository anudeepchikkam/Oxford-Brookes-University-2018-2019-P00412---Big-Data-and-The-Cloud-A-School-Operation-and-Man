<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create Role</h1>
    <form @submit.prevent="createRole">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Slug</label>
            <input type="text" class="form-control" v-model="role.slug">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Name</label>
            <input type="text" class="form-control" v-model="role.name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Permissions</label>
            <select v-model="role.permissions" multiple>
              <option
                v-for="(permission, index) in permissions"
                v-bind:value="permission._id"
                :key="permission._id"
              >{{ index+1 }} - {{ permission.name }}</option>
            </select>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            permissions: [],
            role: {},
        };
    },
    created() {
        let uriPermissions = `http://localhost:4000/api/permissions`;

        this.axios.get(uriPermissions).then(response => {
            this.permissions = response.data;
        });
    },
    methods: {
        createRole() {
            let uri = `http://localhost:4000/api/roles`;
            this.axios
                .post(uri, this.role)
                .then(() => {
                    this.$router.push({ name: 'roles' });
                })
                .catch(console.log);
        },
    },
};
</script>
