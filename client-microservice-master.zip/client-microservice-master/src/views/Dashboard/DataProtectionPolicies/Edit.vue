<template>
  <div>
    <h1>Edit Data Protection policy</h1>
    <form @submit.prevent="updateDataProtectionPolicy">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="dataprotectionpolicy.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            dataprotectionpolicy: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/data-protection-policies/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.dataprotectionpolicy = response.data;
        });
    },
    methods: {
        updateDataProtectionPolicy() {
            let uri = `http://localhost:4000/api/data-protection-policies/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'data-protection-policies' });
            });
        },
    },
};
</script>
