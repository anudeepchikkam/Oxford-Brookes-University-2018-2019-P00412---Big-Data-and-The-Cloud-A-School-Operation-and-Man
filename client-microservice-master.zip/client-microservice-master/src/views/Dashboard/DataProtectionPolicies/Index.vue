<template>
  <div>
    <h1>Data Protection policy</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link
          :to="{ name: 'data-protection-policies-create' }"
          class="btn btn-primary"
        >Create Data Protection policy</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Content</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(dataprotectionpolicy, index) in dataprotectionpolicies"
          :key="dataprotectionpolicy._id"
        >
          <td>{{ index+1 }}</td>
          <td>{{ dataprotectionpolicy.content }}</td>
          <td>
            <router-link
              :to="{name: 'data-protection-policies-edit', params: { id: dataprotectionpolicy._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button
              class="btn btn-danger"
              @click.prevent="deleteDataProtectionPolicy(dataprotectionpolicy._id)"
            >Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            dataprotectionpolicies: [],
        };
    },
    created() {
        let uri = `http://localhost:4000/api/data-protection-policies`;

        this.axios.get(uri).then(response => {
            this.dataprotectionpolicies = response.data;
        });
    },
    methods: {
        deleteDataProtectionPolicy(id) {
            let uri = `http://localhost:4000/api/data-protection-policies/${id}`;

            this.axios.delete(uri).then(response => {
                this.dataprotectionpolicies.splice(this.dataprotectionpolicies.indexOf(id), 1);
            });
        },
    },
};
</script>
