<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create Module</h1>
    <form @submit.prevent="createModule">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Name:</label>
            <input type="text" class="form-control" v-model="module.name">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Teacher Name:</label>
            <input type="text" class="form-control" v-model="module.teacherName">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Year Group:</label>
            <input type="text" class="form-control" v-model="module.yearGroup">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Syllabus:</label>
            <input type="text" class="form-control" v-model="module.syllabus">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Marking Criteria:</label>
            <textarea class="form-control" name="criteria" v-model="module.markingCriteria" rows="10"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      module: {}
    };
  },
  methods: {
    createModule() {
      let uri = `http://localhost:4000/api/modules`;
      // const criteriastring = this.module.markingCriteria.value
      // this.module.markingCriteria = this.module.markingCriteria.replace(/\r|\n|\r\n/g, '<br>')
      this.axios
        .post(uri, this.module)
        .then(() => {
          this.$router.push({ name: "modules" });
        })
        .catch(console.log);
    }
  }
};
</script>
