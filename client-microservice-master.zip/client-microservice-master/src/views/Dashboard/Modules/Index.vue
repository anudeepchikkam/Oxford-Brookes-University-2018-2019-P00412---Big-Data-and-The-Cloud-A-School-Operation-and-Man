<template>
  <div>
    <h1>Modules</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'modules-create' }" class="btn btn-primary">Create Module</router-link>
      </div>
    </div>
    <br>
<b-card class="my-3" v-for="module in modules" :key="module._id">
    <b-card-title>{{ module.name }}</b-card-title>
    <b-card-title>{{ module.teacherName }}</b-card-title>
    <b-card-title>Year Group: {{ module.yearGroup }}</b-card-title>
    <b-card-title>Syllabus: {{ module.syllabus }}</b-card-title>
    
    <b-card-title>Marking Criteria: <span style="white-space: pre;">{{ module.markingCriteria }}</span></b-card-title>

    <!-- <a href="#" class="card-link">Card link</a> -->
    <!-- <b-link href="#" class="card-link">Another link</b-link> -->
     <router-link
              :to="{name: 'modules-edit', params: { id: module._id }}"
              class="btn btn-primary"
            >Edit</router-link>
    <b-link class="btn btn-danger mx-3" @click.prevent="deleteModule(module._id)">Delete</b-link>
  </b-card>
  </div>
</template>

<script>
export default {
    data() {
        return {
            modules: [],
            syllabus: '',
            user: {
                type: 'student',
            },
        };
    },
    created() {
        let uri = `http://localhost:4000/api/modules`;

        this.axios.get(uri).then(response => {
            this.modules = response.data;
            this.syllabus = this.modules.map((x) => {
              return x.syllabus
            }).join(', ')
        });
    },
    methods: {
        deleteModule(id) {
            let uri = `http://localhost:4000/api/modules/${id}`;

            this.axios.delete(uri).then(response => {
                this.modules.splice(this.modules.indexOf(id), 1);
            });
        },
    },
};
</script>
