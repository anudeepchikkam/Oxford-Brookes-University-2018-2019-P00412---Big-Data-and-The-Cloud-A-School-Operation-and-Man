<template>
  <div>
    <h1>Account</h1>
    <form @submit.prevent="updateUser">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Email:</label>
            <input type="email" class="form-control" v-model="user.email">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Password:</label>
            <input type="password" class="form-control" v-model="user.password">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Role:</label>
            <input type="text" class="form-control" v-model="user.role_id" readonly>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            user: {},
        };
    },
    created() {
        let uriUser = `http://localhost:4000/api/users/${this.$route.params.id}`;
        this.axios.get(uriUser).then(response => {
            this.user = response.data;
        });
    },
    methods: {
        updateUser() {
            let uri = `http://localhost:4000/api/users/${this.$route.params.id}`;
            this.axios.post(uri, this.user).then(() => {
                this.$router.push({ name: 'account' });
            });
        },
    },
};
</script>
