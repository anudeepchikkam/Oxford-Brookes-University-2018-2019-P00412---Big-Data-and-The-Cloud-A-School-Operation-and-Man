<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create Post</h1>
    <form @submit.prevent="createPost">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Post Title:</label>
            <input type="text" class="form-control" v-model="post.title">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Post Body:</label>
            <textarea class="form-control" v-model="post.body" rows="5"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      post: {}
    };
  },
  methods: {
    createPost() {
      let uri = `http://localhost:4000/api/posts`;
      this.axios
        .post(uri, this.post)
        .then(() => {
          this.$router.push({ name: "posts" });
        })
        .catch(console.log);
    }
  }
};
</script>
