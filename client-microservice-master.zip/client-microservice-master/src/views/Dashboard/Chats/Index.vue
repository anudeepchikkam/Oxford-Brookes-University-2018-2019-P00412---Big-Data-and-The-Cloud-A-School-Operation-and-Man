<template>
  <div>
    <h1>Roles</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link :to="{ name: 'roles-create' }" class="btn btn-primary">Create Role</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Slug</th>
          <th>Name</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(role, index) in roles" :key="role._id">
          <td>{{ index+1 }}</td>
          <td>{{ role.slug }}</td>
          <td>{{ role.name }}</td>
          <td>
            <router-link
              :to="{name: 'roles-edit', params: { id: role._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button class="btn btn-danger" @click.prevent="deleteRole(role._id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            roles: [],
        };
    },
    created() {
        let uri = `http://localhost:4000/api/roles`;

        this.axios.get(uri).then(response => {
            this.roles = response.data;
        });
    },
    methods: {
        deleteRole(id) {
            let uri = `http://localhost:4000/api/roles/${id}`;

            this.axios.delete(uri).then(response => {
                this.roles.splice(this.roles.indexOf(id), 1);
            });
        },
    },
};
</script>
