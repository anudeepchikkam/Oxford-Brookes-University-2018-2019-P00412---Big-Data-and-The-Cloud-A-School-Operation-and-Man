<template>
  <div>
    <h1>Edit Role</h1>
    <form @submit.prevent="updateRole">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Slug</label>
            <input type="text" class="form-control" v-model="role.slug">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Name</label>
            <input type="text" class="form-control" v-model="role.name">
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            role: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/roles/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.role = response.data;
        });
    },
    methods: {
        updateRole() {
            let uri = `http://localhost:4000/api/roles/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'roles' });
            });
        },
    },
};
</script>
