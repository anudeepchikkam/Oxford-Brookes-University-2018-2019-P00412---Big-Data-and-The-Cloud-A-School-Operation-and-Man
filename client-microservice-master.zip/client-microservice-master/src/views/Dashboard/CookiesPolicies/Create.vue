<template>
  <div>
    <div class="alert alert-warning" v-show="showError">
      <button type="button" class="close" @click="hideMessage()">X</button>
      <strong>Error!</strong>
    </div>
    <h1>Create Cookies policy</h1>
    <form @submit.prevent="createCookiesPolicy">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="cookiespolicy.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Create</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            cookiespolicy: {},
        };
    },
    methods: {
        createCookiesPolicy() {
            let uri = `http://localhost:4000/api/cookies-policies`;
            this.axios
                .post(uri, this.cookiespolicy)
                .then(() => {
                    this.$router.push({ name: 'cookies-policies' });
                })
                .catch(console.log);
        },
    },
};
</script>
