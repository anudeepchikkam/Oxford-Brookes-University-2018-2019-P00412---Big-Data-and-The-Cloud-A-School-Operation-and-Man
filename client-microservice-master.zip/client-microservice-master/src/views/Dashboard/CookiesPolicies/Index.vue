<template>
  <div>
    <h1>Cookies policy</h1>
    <div class="row">
      <div class="col-md-10"></div>
      <div class="col-md-2">
        <router-link
          :to="{ name: 'cookies-policies-create' }"
          class="btn btn-primary"
        >Create Cookies policy</router-link>
      </div>
    </div>
    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>Index</th>
          <th>Content</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(cookiespolicy, index) in cookiespolicies" :key="cookiespolicy._id">
          <td>{{ index+1 }}</td>
          <td>{{ cookiespolicy.content }}</td>
          <td>
            <router-link
              :to="{name: 'cookies-policies-edit', params: { id: cookiespolicy._id }}"
              class="btn btn-primary"
            >Edit</router-link>
          </td>
          <td>
            <button
              class="btn btn-danger"
              @click.prevent="deleteCookiePolicy(cookiespolicy._id)"
            >Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
    data() {
        return {
            cookiespolicies: [],
        };
    },
    created() {
        let uri = `http://localhost:4000/api/cookies-policies`;

        this.axios.get(uri).then(response => {
            this.cookiespolicies = response.data;
        });
    },
    methods: {
        deleteCookiePolicy(id) {
            let uri = `http://localhost:4000/api/cookies-policies/${id}`;

            this.axios.delete(uri).then(response => {
                this.cookiespolicies.splice(this.cookiespolicies.indexOf(id), 1);
            });
        },
    },
};
</script>
