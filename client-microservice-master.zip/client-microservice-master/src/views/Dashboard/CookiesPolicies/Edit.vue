<template>
  <div>
    <h1>Edit Cookies policy</h1>
    <form @submit.prevent="updateCookiesPolicy">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="cookiespolicy.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            cookiespolicy: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/cookies-policies/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.cookiespolicy = response.data;
        });
    },
    methods: {
        updateCookiesPolicy() {
            let uri = `http://localhost:4000/api/cookies-policies/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'cookies-policies' });
            });
        },
    },
};
</script>
