<template>
  <div>
    <h1>Edit Legal notices</h1>
    <form @submit.prevent="updateLegalNotices">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" v-model="legalnotices.content"></textarea>
          </div>
        </div>
      </div>
      <br>
      <div class="form-group">
        <button class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</template>

<script>
export default {
    data() {
        return {
            legalnotices: {},
        };
    },
    created() {
        let uri = `http://localhost:4000/api/legal-notices/${this.$route.params.id}`;
        this.axios.get(uri).then(response => {
            this.legalnotices = response.data;
        });
    },
    methods: {
        updateLegalNotices() {
            let uri = `http://localhost:4000/api/legal-notices/${this.$route.params.id}`;
            this.axios.post(uri, this.post).then(() => {
                this.$router.push({ name: 'legal-notices' });
            });
        },
    },
};
</script>
