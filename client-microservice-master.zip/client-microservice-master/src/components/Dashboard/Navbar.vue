<template>
  <div>
    <b-navbar toggleable="lg" type="dark" variant="info">
      <b-navbar-brand :to="{ name: 'Dashboard' }">ASOAMS</b-navbar-brand>
      <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>
      <b-collapse id="nav-collapse" is-nav>

        <!-- Right aligned nav items -->
        <b-navbar-nav class="ml-auto">
          <b-navbar-nav>
            <b-nav-item href="#"><fa-icon icon="bell" class="text-white"/></b-nav-item>
          </b-navbar-nav>

          <b-nav-item-dropdown text="Language" right>
            <b-dropdown-item href="#">EN</b-dropdown-item>
            <b-dropdown-item href="#">ES</b-dropdown-item>
            <b-dropdown-item href="#">RU</b-dropdown-item>
            <b-dropdown-item href="#">FA</b-dropdown-item>
          </b-nav-item-dropdown>

          <b-nav-item-dropdown right>
            <!-- Using 'button-content' slot -->
            <template slot="button-content">
              <img class="nav-photo" :src="user.photo"> {{ user.firstName }}
            </template>
            <b-dropdown-item :to="{ name: 'profile', params: { id: 123 }}">View Profile</b-dropdown-item>
            <b-dropdown-item href="#">Edit Profile</b-dropdown-item>
            <b-dropdown-item href="#">Account</b-dropdown-item>
            <b-dropdown-item href="#">Sign Out</b-dropdown-item>
          </b-nav-item-dropdown>
        </b-navbar-nav>
      </b-collapse>
    </b-navbar>
  </div>
</template>
<script lang="ts">

export default {
  name: "Navbar",
  data() {
    return {
      user: {
        firstName: 'Jeiman',
        photo: 'https://scontent-lht6-1.xx.fbcdn.net/v/t1.0-9/50601709_10161136540310316_2589377319663566848_o.jpg?_nc_cat=104&_nc_ht=scontent-lht6-1.xx&oh=ade271932ac2925747b8cd7f89c9d8ca&oe=5D6A3641',
      }
    }
  }
};
</script>