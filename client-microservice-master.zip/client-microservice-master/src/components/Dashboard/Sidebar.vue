<template>
  <div class="bg-secondary sidebar-container sidebar">
    <!-- <b-nav vertical class="text-left d-none d-md-block">
      <div class="sidebar-sticky">
      <div v-if="user.type === 'student'">
        <b-nav-item :to="'events'"><fa-icon icon="calendar-alt" class="text-white"/> Events</b-nav-item>
        <b-nav-item :to="'meetings'"><fa-icon icon="handshake" class="text-white"/> Meetings</b-nav-item>

        <b-nav-item v-b-toggle.collapse-1 variant="primary"><fa-icon icon="book-open" class="text-white"/> Modules <fa-icon icon="caret-down" class="text-white"/></b-nav-item>
        <b-collapse id="collapse-1" class="mt-2">
          <b-nav-item v-for="(module, index) in user.modules" :key="index" :to="'modules'">{{ module }}</b-nav-item>
        </b-collapse>

        <b-nav-item :to="{ name: 'posts' }">Posts</b-nav-item>

      </div>
      <div v-if="user.type === 'teacher'">

      </div>
      <div v-if="user.type === 'parent'">

      </div>
      <div v-if="user.type === 'schoolManager'">

      </div>
      <div v-if="user.type === 'eventOrganiser'">

      </div>
      <div v-if="user.type === 'systemOperator'">

      </div>
      <b-nav-item :to="'chats'"><fa-icon icon="comments" class="text-white"/> Chat</b-nav-item>
      </div>
    </b-nav> -->
  </div>
</template>

<script lang="ts">

export default {
  name: "Sidebar",
  data() {
    return {
    }
  },
  created () {
  },

  methods: {
  }
};
</script>