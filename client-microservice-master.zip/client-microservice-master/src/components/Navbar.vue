<template>
  <div>
    <b-navbar toggleable="md" type="dark" class="fixed-top bg-dark flex-md-nowrap p-0 shadow">
      <b-navbar-brand :to="'Dashboard'" class="col-xs-3 col-sm-3 col-md-2 mr-0">ASOAMS</b-navbar-brand>

      <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

      <b-collapse id="nav-collapse" is-nav>
        <b-navbar-nav>
          <b-nav-item :to="{ name: 'home'}">Home</b-nav-item>
          <b-nav-item :to="{ name: 'about-latest'}">About</b-nav-item>
          <b-nav-item-dropdown text="Legal">
            <b-dropdown-item :to="{ name: 'cookies-policy-latest'}">Cookies policy</b-dropdown-item>
            <b-dropdown-item :to="{ name: 'credits-latest'}">Credits</b-dropdown-item>
            <b-dropdown-item :to="{ name: 'data-protection-policy-latest'}">Data Protection policy</b-dropdown-item>
            <b-dropdown-item :to="{ name: 'legal-notices-latest'}">Legal notices</b-dropdown-item>
            <b-dropdown-item :to="{ name: 'terms-of-service-latest'}">Terms of service</b-dropdown-item>
          </b-nav-item-dropdown>
          <b-nav-item :to="{ name: 'contact'}">Contact Us</b-nav-item>
          <div class="d-md-none">
            <sidebar-menu/>
          </div>
        </b-navbar-nav>
      </b-collapse>
      <b-navbar-nav class="ml-auto">
        <!--
        <b-nav-item-dropdown text="Language" right>
          <b-dropdown-item href="#">EN</b-dropdown-item>
          <b-dropdown-item href="#">FR</b-dropdown-item>
        </b-nav-item-dropdown>
        -->
        <b-nav-item-dropdown right>
          <!-- Using 'button-content' slot -->
          <template slot="button-content">
            <img class="nav-photo" :src="user.photo">
            {{ user.firstName }}
          </template>
          <b-dropdown-item :to="{ name: 'account', params: { id: 123 }}">Account</b-dropdown-item>
          <b-dropdown-item :to="{ name: 'profile', params: { id: 123 }}">Profile</b-dropdown-item>
          <b-dropdown-item :to="{ name: 'setting', params: { id: 123 }}">Setting</b-dropdown-item>
          <b-dropdown-item href="#">Sign Out</b-dropdown-item>
        </b-nav-item-dropdown>
      </b-navbar-nav>
    </b-navbar>
  </div>
</template>

<script lang="ts">
import SidebarMenu from '@/components/SidebarMenu.vue';

export default {
    name: 'Navbar',
    components: {
        SidebarMenu,
    },
    data() {
        return {
            user: {
                firstName: 'Jeiman',
                photo:
                    'https://scontent-lht6-1.xx.fbcdn.net/v/t1.0-9/50601709_10161136540310316_2589377319663566848_o.jpg?_nc_cat=104&_nc_ht=scontent-lht6-1.xx&oh=ade271932ac2925747b8cd7f89c9d8ca&oe=5D6A3641',
            },
        };
    },
};
</script>