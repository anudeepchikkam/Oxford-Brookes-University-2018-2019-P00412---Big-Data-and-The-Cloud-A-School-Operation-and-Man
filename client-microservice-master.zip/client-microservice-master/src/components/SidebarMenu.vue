<template>
  <div>
    <b-nav-item :to="{ name: 'Dashboard' }">
      <fa-icon icon="home" class="feather" fixed-width/>Dashboard
    </b-nav-item>
    <b-nav-item :to="{ name: 'event'}">
      <fa-icon icon="calendar-alt" class="feather" fixed-width/>Events
    </b-nav-item>
    <b-nav-item :to="{ name: 'invitations' }">
      <fa-icon icon="envelope-open-text" class="feather" fixed-width/>Invitations
    </b-nav-item>
    <b-nav-item :to="{ name: 'meetings' }">
      <fa-icon icon="handshake" class="feather" fixed-width/>Meetings
    </b-nav-item>

    <b-nav-item :to="{ name: 'posts' }">
      <fa-icon icon="clipboard" class="feather" fixed-width/>Posts
    </b-nav-item>

    <div v-if="user.type === 'teacher'"></div>
    <div v-if="user.type === 'parent'"></div>
    <div v-if="user.type === 'schoolManager'"></div>
    <div v-if="user.type === 'eventOrganiser'"></div>
    <div v-if="user.type === 'systemOperator'"></div>

    <b-nav-item :to="{ name: 'chats'}">
      <fa-icon icon="comments" class="feather" fixed-width/>Chat
    </b-nav-item>

    <b-nav-item :to="{ name: 'account', params: { id: 1 } }">Account</b-nav-item>

    <b-nav-item :to="{ name: 'profile', params: { id: 1 } }">Profile</b-nav-item>

    <b-nav-item :to="{ name: 'setting', params: { id: 1 } }">Setting</b-nav-item>

    <h6
      class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted"
    >
      <span>School Managers</span>
      <router-link :to="{}">
        <fa-icon
          icon="plus-circle"
          class="feather d-flex align-items-center text-muted"
          fixed-width
        />
      </router-link>
    </h6>

    <b-nav-item :to="{ name: 'abouts' }">About</b-nav-item>
    <b-nav-item :to="{ name: 'cookies-policies' }">Cookies policy</b-nav-item>
    <b-nav-item :to="{ name: 'credits' }">Credits</b-nav-item>
    <b-nav-item :to="{ name: 'data-protection-policies' }">Data Protection policy</b-nav-item>
    <b-nav-item :to="{ name: 'legal-notices' }">Legal notices</b-nav-item>
    <b-nav-item :to="{ name: 'payments' }">Payments records</b-nav-item>
    <b-nav-item :to="{ name: 'terms-of-services' }">Terms of service</b-nav-item>
    <b-nav-item :to="{ name: 'users' }">Users</b-nav-item>

    <h6
      class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted"
    >
      <span>Students</span>
      <router-link :to="{}">
        <fa-icon
          icon="plus-circle"
          class="feather d-flex align-items-center text-muted"
          fixed-width
        />
      </router-link>
    </h6>

    <div v-if="user.type === 'student'">
      <b-nav-item v-b-toggle.collapse-1 variant="primary">
        <fa-icon icon="book-open" class="feather" fixed-width/>My modules
        <fa-icon icon="caret-down" class="feather" fixed-width/>
      </b-nav-item>
      <b-collapse id="collapse-1" class="mt-2">
        <b-nav-item
          v-for="(module, index) in user.modules"
          :key="index"
          v-b-toggle.collapse-2-inner
          size="sm"
        >
          {{ module }}
          <fa-icon icon="caret-down" class="feather" fixed-width/>
          <b-collapse id="collapse-2-inner" class="mt-2">
            <b-nav-item :to="{}">Key Resources</b-nav-item>
            <b-nav-item :to="{}">Grades</b-nav-item>
            <b-nav-item :to="{}">Homework</b-nav-item>
            <b-nav-item :to="{}">Assessments</b-nav-item>
          </b-collapse>
        </b-nav-item>
      </b-collapse>

      <b-nav-item :to="{ name: 'modules' }">
        <fa-icon icon="plus-square" class="feather" fixed-width/>Register for module
      </b-nav-item>
    </div>

    <b-nav-item :to="''">Parent(s)</b-nav-item>

    <h6
      class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted"
    >
      <span>Teachers</span>
      <router-link :to="{}">
        <fa-icon
          icon="plus-circle"
          class="feather d-flex align-items-center text-muted"
          fixed-width
        />
      </router-link>
    </h6>

    <b-nav-item :to="{ name: 'modules' }">Modules</b-nav-item>

    <div v-if="user.type === 'teacher'">
      <b-nav-item v-b-toggle.collapse-1 variant="primary">
        <fa-icon icon="book-open" class="feather" fixed-width/>My modules
        <fa-icon icon="caret-down" class="feather" fixed-width/>
      </b-nav-item>
      <b-collapse id="collapse-1" class="mt-2">
        <!--<b-nav-item
          v-for="(module, index) in user.modules"
          :key="index"
          :to="'modules'"
        >{{ module }}</b-nav-item>-->
        <b-nav-item
          v-for="(module, index) in user.modules"
          :key="index"
          v-b-toggle.collapse-1-inner
          size="sm"
        >
          {{ module }}
          <fa-icon icon="caret-down" class="feather" fixed-width/>
          <b-collapse id="collapse-1-inner" class="mt-2">
            <b-nav-item :to="{}">Key Resources</b-nav-item>
            <b-nav-item :to="{}">Grades</b-nav-item>
            <b-nav-item :to="{}">Homework</b-nav-item>
            <b-nav-item :to="{}">Assessments</b-nav-item>
          </b-collapse>
        </b-nav-item>
      </b-collapse>

      <b-nav-item :to="{ name: 'modules' }">
        <fa-icon icon="plus-square" class="feather" fixed-width/>Register for module
      </b-nav-item>
    </div>

    <h6
      class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted"
    >
      <span>Parents</span>
      <router-link :to="{}">
        <fa-icon
          icon="plus-circle"
          class="feather d-flex align-items-center text-muted"
          fixed-width
        />
      </router-link>
    </h6>

    <b-nav-item :to="{ name: 'payment' }">Payments records</b-nav-item>
    <b-nav-item :to="''">Child(ren)</b-nav-item>

    <h6
      class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted"
    >
      <span>Events Organizers</span>
      <router-link :to="{}">
        <fa-icon
          icon="plus-circle"
          class="feather d-flex align-items-center text-muted"
          fixed-width
        />
      </router-link>
    </h6>

    <b-nav-item :to="{ name: 'events' }">Manage Events</b-nav-item>

    <h6
      class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted"
    >
      <span>System Operators</span>
      <router-link :to="{}">
        <fa-icon
          icon="plus-circle"
          class="feather d-flex align-items-center text-muted"
          fixed-width
        />
      </router-link>
    </h6>

    <!--<b-nav-item :to="{ name: 'accounts' }">Accounts</b-nav-item>-->

    <b-nav-item :to="{ name: 'permissions' }">Permissions</b-nav-item>

    <b-nav-item :to="{ name: 'profiles' }">Profiles</b-nav-item>

    <b-nav-item :to="{ name: 'roles' }">Roles</b-nav-item>

    <b-nav-item :to="{ name: 'settings' }">Settings</b-nav-item>

    <b-nav-item :to="{ name: 'users' }">Users</b-nav-item>

    <h6
      class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted"
    >
      <span>Claims</span>
      <router-link :to="{}">
        <fa-icon
          icon="plus-circle"
          class="feather d-flex align-items-center text-muted"
          fixed-width
        />
      </router-link>
    </h6>
    <b-nav-item :to="{}">
      <fa-icon icon="file-alt" class="feather" fixed-width/>Maths marks
    </b-nav-item>
    <b-nav-item :to="{}">
      <fa-icon icon="file-alt" class="feather" fixed-width/>Access to other modules
    </b-nav-item>
    <b-nav-item :to="{}">
      <fa-icon icon="file-alt" class="feather" fixed-width/>Late fees 2019
    </b-nav-item>
    <b-nav-item :to="{}">
      <fa-icon icon="file-alt" class="feather" fixed-width/>Misconduct review
    </b-nav-item>
  </div>
</template>

<script>
export default {
    name: 'SidebarMenu',
    data() {
        return {
            user: {
                type: 'student',
                modules: ['Maths', 'Science', 'English', 'History'],
            },
        };
    },
    created() {},

    methods: {},
};
</script>