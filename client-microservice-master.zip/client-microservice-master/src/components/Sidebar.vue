<template>
  <nav class="col-xs-3 col-md-2 d-none d-md-block bg-light sidebar">
    <div class="sidebar-sticky">
      <b-nav vertical>
        <sidebar-menu/>
      </b-nav>
    </div>
  </nav>
</template>

<script>
import SidebarMenu from '@/components/SidebarMenu.vue';

export default {
    name: 'Sidebar',
    components: {
        SidebarMenu,
    },
    data() {
        return {};
    },
    created() {},

    methods: {},
};
</script>