// Import Vue library, state management and router, and other package libraries
import Vue from 'vue';
import VueAxios from 'vue-axios';
import axios from 'axios';
import PortalVue from 'portal-vue';
import BootstrapVue from 'bootstrap-vue';
const { Datetime } = require('vue-datetime');
import Editor from '@tinymce/tinymce-vue';
import App from './App.vue';
import router from './router';
import store from './store';
import { library, config } from '@fortawesome/fontawesome-svg-core';
import { fab } from '@fortawesome/free-brands-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon, FontAwesomeLayers, FontAwesomeLayersText } from '@fortawesome/vue-fontawesome';
import './registerServiceWorker';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap-vue/dist/bootstrap-vue.css';
import './styles/style.scss';
import 'vue-datetime/dist/vue-datetime.css'

// Instantiate libraries and components to be used in the system
library.add(fab, far, fas);

Vue.component('fa-icon', FontAwesomeIcon);
Vue.component('fa-layers', FontAwesomeLayers);
Vue.component('fa-layers-text', FontAwesomeLayersText);
Vue.component('datetime', Datetime);
Vue.component('editor', Editor);

Vue.config.productionTip = false;

Vue.use(VueAxios, axios);
Vue.use(PortalVue);
Vue.use(BootstrapVue);

// Creates the Vue instance, rendering the router, state management into the framework and finally mounting the entire system on a HTML div element #app
new Vue({
    router,
    store,
    render: h => h(App),
}).$mount('#app');
